#include "chess/selfplay.hpp"
#include "chess/zobrist.hpp"
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>

using namespace ae::chess;

namespace {
void usage() {
    std::cout << "Project-AE Self-Play\n"
              << "Usage: ae_selfplay [games] [depth] [max_plies] [output.pgn]\n"
              << "Defaults: games=1 depth=3 max_plies=300 output=selfplay.pgn\n";
}

int parse_int(const char* text, int fallback) {
    try { return std::stoi(text); } catch (...) { return fallback; }
}
}

int main(int argc, char** argv) {
    if (argc > 1 && std::string(argv[1]) == "--help") {
        usage();
        return 0;
    }

    SelfPlayConfig config;
    config.games = argc > 1 ? static_cast<unsigned>(parse_int(argv[1], 1)) : 1u;
    config.depth = argc > 2 ? parse_int(argv[2], 3) : 3;
    config.max_plies = argc > 3 ? parse_int(argv[3], 300) : 300;
    const std::string output_path = argc > 4 ? argv[4] : "selfplay.pgn";

    if (config.games == 0 || config.depth < 1 || config.max_plies < 1) {
        std::cerr << "Invalid arguments.\n";
        usage();
        return 1;
    }

    std::ofstream out(output_path, std::ios::trunc);
    if (!out) {
        std::cerr << "Unable to open output: " << output_path << "\n";
        return 1;
    }

    std::uint64_t total_nodes = 0;
    unsigned white_wins = 0;
    unsigned black_wins = 0;
    unsigned draws = 0;

    for (unsigned game_no = 1; game_no <= config.games; ++game_no) {
        const auto game = play_self_game(config, config.seed + game_no - 1);
        out << game_to_pgn(game, static_cast<int>(game_no)) << '\n';
        total_nodes += game.nodes;
        switch (game.result) {
        case GameResult::WhiteWin: ++white_wins; break;
        case GameResult::BlackWin: ++black_wins; break;
        case GameResult::Draw: ++draws; break;
        case GameResult::Ongoing: break;
        }
        std::cout << "Game " << game_no
                  << ": result=" << game_result_pgn(game.result)
                  << " plies=" << game.plies
                  << " nodes=" << game.nodes
                  << " time_ms=" << game.elapsed_ms << '\n';
    }

    std::cout << "Self-play complete\n"
              << "Games: " << config.games << '\n'
              << "White wins: " << white_wins << '\n'
              << "Black wins: " << black_wins << '\n'
              << "Draws: " << draws << '\n'
              << "Total nodes: " << total_nodes << '\n'
              << "PGN: " << output_path << '\n';
    return 0;
}
