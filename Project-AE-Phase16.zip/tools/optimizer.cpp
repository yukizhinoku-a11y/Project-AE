#include "chess/optimizer.hpp"
#include "chess/zobrist.hpp"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace ae::chess;

namespace {
void usage() {
    std::cout << "Project-AE Automated Parameter Search v1\n"
              << "Usage: ae_optimizer [games] [depth] [max_plies] [node_limit] [seed] [step] [csv] [parameter...]\n"
              << "parameter format: name or name=step\n"
              << "example: ae_optimizer 20 1 20 0 42 5 optimizer_results.csv pawn_value bishop_pair_bonus\n"
              << "example: ae_optimizer 20 1 20 0 42 5 optimizer_results.csv pawn_value=5 knight_mobility=1\n"
              << "defaults: games=4 depth=1 max_plies=20 node_limit=0 seed=1 step=5 csv=optimizer_results.csv\n";
}

bool parse_u64(const std::string& s, std::uint64_t& out) { try { out = std::stoull(s); return true; } catch (...) { return false; } }
bool parse_unsigned(const std::string& s, unsigned& out) { try { out = static_cast<unsigned>(std::stoul(s)); return true; } catch (...) { return false; } }
bool parse_int(const std::string& s, int& out) { try { out = std::stoi(s); return true; } catch (...) { return false; } }
std::string csv_escape(const std::string& value) {
    if (value.find_first_of(",\"") == std::string::npos) return value;
    std::string out = "\"";
    for (char c : value) { if (c == '"') out += "\"\""; else out += c; }
    out += '"';
    return out;
}
}

int main(int argc, char** argv) {
    if (argc > 1 && std::string(argv[1]) == "--help") { usage(); return 0; }

    TuningConfig config;
    int default_step = 5;
    std::string csv_path = "optimizer_results.csv";
    std::vector<SearchParameter> parameters;

    if (argc > 1 && !parse_unsigned(argv[1], config.games)) { usage(); return 1; }
    if (argc > 2 && !parse_int(argv[2], config.depth)) { usage(); return 1; }
    if (argc > 3 && !parse_int(argv[3], config.max_plies)) { usage(); return 1; }
    if (argc > 4 && !parse_u64(argv[4], config.node_limit)) { usage(); return 1; }
    if (argc > 5 && !parse_u64(argv[5], config.seed)) { usage(); return 1; }
    if (argc > 6 && !parse_int(argv[6], default_step)) { usage(); return 1; }
    if (argc > 7) csv_path = argv[7];

    for (int i = 8; i < argc; ++i) {
        const std::string arg = argv[i];
        const auto eq = arg.find('=');
        SearchParameter parameter;
        parameter.name = eq == std::string::npos ? arg : arg.substr(0, eq);
        parameter.step = default_step;
        if (eq != std::string::npos) {
            if (!parse_int(arg.substr(eq + 1), parameter.step)) { usage(); return 1; }
        }
        if (parameter.name.empty() || parameter.step <= 0) { usage(); return 1; }
        parameters.push_back(std::move(parameter));
    }
    if (parameters.empty()) {
        parameters = {{"pawn_value", default_step}, {"bishop_pair_bonus", default_step}};
    }
    if (config.games == 0 || config.depth < 1 || config.max_plies < 1 || config.threads == 0) {
        std::cerr << "Invalid optimizer configuration.\n";
        return 1;
    }

    zobrist::init();
    EvaluationParams best = EvaluationParams::default_v1();
    OptimizationResult result;
    std::string error;
    if (!optimize_parameters(best, parameters, config, result, &error)) {
        std::cerr << "Optimization error: " << error << "\n";
        return 1;
    }

    std::ofstream csv(csv_path, std::ios::trunc);
    if (!csv) { std::cerr << "Cannot open CSV: " << csv_path << "\n"; return 1; }
    csv << "parameter,starting_value,candidate_value,decision,games,candidate_wins,baseline_wins,draws,score_percent,ci95_low,ci95_high,total_nodes,total_time_ms,seed,selected_value\n";

    std::cout << "Project-AE Automated Parameter Search v1\n"
              << "Parameters: " << parameters.size() << "\n"
              << "Games per candidate: " << config.games << "\n"
              << "Accepted changes: " << result.accepted_changes << "\n\n";

    std::size_t experiment_index = 0;
    for (const OptimizationStep& step : result.steps) {
        std::cout << step.parameter << " (start=" << step.starting_value
                  << ", selected=" << step.selected_value << ")\n";
        for (const OptimizationCandidateResult& candidate : step.candidates) {
            const auto& s = candidate.summary;
            const auto& st = candidate.statistics;
            const std::uint64_t seed = config.seed + static_cast<std::uint64_t>(experiment_index) * 1000003ULL;
            std::cout << "  " << candidate.value << ": " << optimization_decision_name(candidate.decision)
                      << ", score=" << std::fixed << std::setprecision(2) << s.candidate_score_percent()
                      << "%, CI=[" << st.confidence_low * 100.0 << "%, " << st.confidence_high * 100.0
                      << "%], games=" << s.games << "\n";
            csv << csv_escape(step.parameter) << ',' << step.starting_value << ',' << candidate.value << ','
                << optimization_decision_name(candidate.decision) << ',' << s.games << ','
                << s.candidate_wins << ',' << s.baseline_wins << ',' << s.draws << ','
                << s.candidate_score_percent() << ',' << st.confidence_low * 100.0 << ','
                << st.confidence_high * 100.0 << ',' << s.nodes << ',' << s.elapsed_ms << ','
                << seed << ',' << step.selected_value << '\n';
            ++experiment_index;
        }
        std::cout << "\n";
    }

    std::cout << "Final parameter set:\n";
    std::cout << "  pawn_value=" << best.pawn_value << "\n"
              << "  knight_value=" << best.knight_value << "\n"
              << "  bishop_value=" << best.bishop_value << "\n"
              << "  rook_value=" << best.rook_value << "\n"
              << "  queen_value=" << best.queen_value << "\n"
              << "  bishop_pair_bonus=" << best.bishop_pair_bonus << "\n"
              << "CSV: " << csv_path << "\n";
    return 0;
}
