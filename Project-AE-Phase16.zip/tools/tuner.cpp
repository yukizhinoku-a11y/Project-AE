#include "chess/tuning.hpp"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace ae::chess;

namespace {
void usage() {
    std::cout << "Project-AE Statistical Tuning v1\n"
              << "Usage: ae_tuner [games] [depth] [max_plies] [node_limit] [seed] [candidate...] [csv]\n"
              << "candidate format: name=value; multiple candidates are allowed\n"
              << "example: ae_tuner 20 1 20 0 42 pawn_value=95 pawn_value=100 pawn_value=105 results.csv\n"
              << "defaults: games=4 depth=1 max_plies=20 node_limit=0 seed=1 candidate=pawn_value=105 csv=tuning_results.csv\n";
}

bool parse_u64(const std::string& s, std::uint64_t& out) {
    try { out = std::stoull(s); return true; } catch (...) { return false; }
}
bool parse_unsigned(const std::string& s, unsigned& out) {
    try { out = static_cast<unsigned>(std::stoul(s)); return true; } catch (...) { return false; }
}
bool parse_int(const std::string& s, int& out) {
    try { out = std::stoi(s); return true; } catch (...) { return false; }
}
bool parse_candidate(const std::string& text, ParameterChange& change) {
    const auto pos = text.find('=');
    if (pos == std::string::npos || pos == 0 || pos + 1 >= text.size()) return false;
    change.name = text.substr(0, pos);
    return parse_int(text.substr(pos + 1), change.value);
}
std::string csv_escape(const std::string& value) {
    if (value.find_first_of(",\"") == std::string::npos) return value;
    std::string out = "\"";
    for (char c : value) { if (c == '"') out += "\"\""; else out += c; }
    out += '"';
    return out;
}
std::string status(const MatchStatistics& s) {
    if (s.statistically_above_baseline) return "above_baseline_95ci";
    if (s.statistically_below_baseline) return "below_baseline_95ci";
    return "inconclusive";
}
}

int main(int argc, char** argv) {
    if (argc > 1 && std::string(argv[1]) == "--help") { usage(); return 0; }

    TuningConfig config;
    std::vector<ExperimentCandidate> candidates;
    std::string csv_path = "tuning_results.csv";

    if (argc > 1 && !parse_unsigned(argv[1], config.games)) { usage(); return 1; }
    if (argc > 2 && !parse_int(argv[2], config.depth)) { usage(); return 1; }
    if (argc > 3 && !parse_int(argv[3], config.max_plies)) { usage(); return 1; }
    if (argc > 4 && !parse_u64(argv[4], config.node_limit)) { usage(); return 1; }
    if (argc > 5 && !parse_u64(argv[5], config.seed)) { usage(); return 1; }

    for (int i = 6; i < argc; ++i) {
        const std::string arg = argv[i];
        if (arg.find('=') == std::string::npos) {
            csv_path = arg;
            break;
        }
        ParameterChange change;
        if (!parse_candidate(arg, change)) { usage(); return 1; }
        candidates.push_back({change.name + "=" + std::to_string(change.value), {change}});
    }
    if (candidates.empty()) candidates.push_back({"pawn_value=105", {{"pawn_value", 105}}});

    if (config.games == 0 || config.depth < 1 || config.max_plies < 1) {
        std::cerr << "Invalid tuning configuration.\n";
        return 1;
    }

    const EvaluationParams baseline = EvaluationParams::default_v1();
    std::string error;
    const auto results = run_tuning_experiments(baseline, candidates, config, &error);
    if (results.empty() && !candidates.empty()) {
        std::cerr << "Experiment error: " << error << "\n";
        return 1;
    }

    std::ofstream csv(csv_path, std::ios::trunc);
    if (!csv) {
        std::cerr << "Cannot open CSV: " << csv_path << "\n";
        return 1;
    }
    csv << "label,parameter, value,games,candidate_wins,baseline_wins,draws,score_percent,ci95_low,ci95_high,status,total_nodes,total_time_ms,seed\n";
    std::cout << "Project-AE Statistical Tuning v1\n"
              << "Candidates: " << results.size() << "\n"
              << "Games per candidate: " << config.games << "\n\n";

    for (const auto& result : results) {
        const auto& s = result.summary;
        const auto& st = result.statistics;
        const auto& change = result.changes.front();
        std::cout << result.label << "\n"
                  << "  Games: " << s.games << "\n"
                  << "  Candidate wins: " << s.candidate_wins << "\n"
                  << "  Baseline wins: " << s.baseline_wins << "\n"
                  << "  Draws: " << s.draws << "\n"
                  << std::fixed << std::setprecision(2)
                  << "  Candidate score: " << s.candidate_score_percent() << "%\n"
                  << "  95% CI: [" << st.confidence_low * 100.0 << "%, " << st.confidence_high * 100.0 << "%]\n"
                  << "  Status: " << status(st) << "\n"
                  << "  Nodes: " << s.nodes << "\n"
                  << "  Time_ms: " << s.elapsed_ms << "\n\n";

        csv << csv_escape(result.label) << ',' << csv_escape(change.name) << ',' << change.value << ','
            << s.games << ',' << s.candidate_wins << ',' << s.baseline_wins << ',' << s.draws << ','
            << s.candidate_score_percent() << ',' << st.confidence_low * 100.0 << ','
            << st.confidence_high * 100.0 << ',' << status(st) << ',' << s.nodes << ','
            << s.elapsed_ms << ',' << (config.seed + (&result - results.data()) * 1000003ULL) << '\n';
    }
    std::cout << "CSV: " << csv_path << "\n";
    return 0;
}
