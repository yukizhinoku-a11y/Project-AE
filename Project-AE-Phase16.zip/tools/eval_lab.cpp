#include "chess/evaluation.hpp"
#include "chess/fen.hpp"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace ae::chess;

struct Entry { std::string id, category, fen, rule, reference; };

int main() {
    std::ifstream in(PHASE10_SUITE_PATH);
    if (!in) { std::cerr << "Could not open Phase 10 suite\n"; return 1; }
    std::vector<Entry> entries;
    std::string line;
    while (std::getline(in, line)) {
        if (line.empty() || line[0] == '#') continue;
        std::stringstream ss(line);
        Entry e;
        if (!std::getline(ss, e.id, '|') || !std::getline(ss, e.category, '|') ||
            !std::getline(ss, e.fen, '|') || !std::getline(ss, e.rule, '|') ||
            !std::getline(ss, e.reference)) return 1;
        entries.push_back(std::move(e));
    }
    EvaluationParams params = EvaluationParams::default_v1();
    std::cout << "Project-AE Phase 10 Evaluation Laboratory\n\n";
    std::cout << std::left << std::setw(26) << "ID" << std::setw(18) << "Category" << "Score\n";
    std::cout << std::string(58, '-') << '\n';
    for (const auto& e : entries) {
        Position pos;
        std::string error;
        if (!set_from_fen(pos, e.fen, &error)) {
            std::cerr << e.id << ": invalid FEN: " << error << '\n';
            return 1;
        }
        std::cout << std::left << std::setw(26) << e.id << std::setw(18) << e.category
                  << evaluate(pos, params) << '\n';
    }
    return 0;
}
