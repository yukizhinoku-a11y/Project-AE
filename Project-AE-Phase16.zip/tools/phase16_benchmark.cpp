#include "chess/fen.hpp"
#include "chess/game.hpp"
#include "chess/search.hpp"
#include "chess/zobrist.hpp"
#include <algorithm>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

using namespace ae::chess;

struct BenchCase { const char* name; const char* fen; };
struct BenchResult {
    double ms{};
    std::uint64_t nodes{};
    double nps{};
    SearchMetrics metrics{};
    Move best{};
    int score{};
    int depth{};
};

BenchResult run(const Position& position, const SearchOptions& options, int depth, int repeats, std::uint64_t node_limit) {
    double total_ms = 0.0;
    std::uint64_t total_nodes = 0;
    SearchResult last{};
    for (int i = 0; i < repeats; ++i) {
        Searcher searcher;
        const auto start = std::chrono::steady_clock::now();
        last = searcher.search(position, SearchLimits{depth, node_limit, 1, options});
        const auto elapsed = std::chrono::steady_clock::now() - start;
        total_ms += std::chrono::duration<double, std::milli>(elapsed).count();
        total_nodes += last.nodes;
    }
    BenchResult out;
    out.ms = total_ms / repeats;
    out.nodes = total_nodes / repeats;
    out.nps = out.ms > 0.0 ? static_cast<double>(out.nodes) / (out.ms / 1000.0) : 0.0;
    out.metrics = last.metrics;
    out.best = last.best_move;
    out.score = last.score;
    out.depth = last.depth;
    return out;
}

void print_row(const std::string& label, const BenchResult& r) {
    std::cout << std::left << std::setw(24) << label
              << std::right << std::setw(10) << r.nodes
              << std::setw(12) << std::fixed << std::setprecision(2) << r.ms
              << std::setw(12) << std::setprecision(0) << r.nps
              << std::setw(10) << r.metrics.tt_hits
              << std::setw(10) << r.metrics.pvs_searches
              << std::setw(10) << r.metrics.lmr_reductions
              << std::setw(10) << r.metrics.null_move_cutoffs
              << std::setw(10) << r.metrics.aspiration_failures
              << '\n';
}

int main(int argc, char** argv) {
    zobrist::init();
    int depth = argc > 1 ? std::max(2, std::stoi(argv[1])) : 5;
    int repeats = argc > 2 ? std::max(1, std::stoi(argv[2])) : 1;
    std::uint64_t node_limit = argc > 3 ? static_cast<std::uint64_t>(std::stoull(argv[3])) : 10000;

    const std::vector<BenchCase> cases = {
        {"startpos", "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"},
        {"kiwipete", "r3k2r/p1ppqpb1/bn2pnp1/2pP4/1p2P3/2N2N2/PPPB1PPP/R2QKB1R w KQkq - 0 1"},
        {"middlegame", "r1bq1rk1/ppp2ppp/2n1pn2/8/2BPP3/2N1BN2/PPP2PPP/R2Q1RK1 w - - 0 1"}
    };

    struct Config { const char* name; SearchOptions options; };
    const std::vector<Config> configs = {
        {"baseline", {false, false, false, false}},
        {"+PVS", {true, false, false, false}},
        {"+LMR", {false, true, false, false}},
        {"+null", {false, false, true, false}},
        {"+asp", {false, false, false, true}},
        {"V2 all", {true, true, true, true}}
    };

    std::cout << "Project-AE Phase 16 Search Benchmark\n"
              << "Depth: " << depth << "  Repeats: " << repeats << "  Node limit: " << node_limit << "\n"
              << "Baseline = Phase-7-style alpha-beta/TT/ordering without Phase-15 additions\n"
              << "Feature rows isolate each Phase-15 addition; V2 all enables all four.\n\n";

    double base_total_ms = 0.0, v2_total_ms = 0.0;
    std::uint64_t base_total_nodes = 0, v2_total_nodes = 0;

    for (const auto& test : cases) {
        Position p;
        std::string error;
        if (!set_from_fen(p, test.fen, &error)) {
            std::cerr << test.name << ": FEN error: " << error << '\n';
            return 1;
        }
        std::cout << "\n[" << test.name << "]\n";
        std::cout << std::left << std::setw(16) << "Configuration"
                  << std::right << std::setw(10) << "Nodes"
                  << std::setw(12) << "Time(ms)"
                  << std::setw(12) << "NPS"
                  << std::setw(10) << "TT hits"
                  << std::setw(10) << "PVS"
                  << std::setw(10) << "LMR"
                  << std::setw(10) << "Null cut"
                  << std::setw(10) << "Asp fail" << '\n';

        BenchResult baseline_result{};
        BenchResult v2_result{};
        for (const auto& config : configs) {
            const auto r = run(p, config.options, depth, repeats, node_limit);
            print_row(config.name, r);
            if (std::string(config.name) == "baseline") baseline_result = r;
            if (std::string(config.name) == "V2 all") v2_result = r;
        }

        base_total_ms += baseline_result.ms; v2_total_ms += v2_result.ms;
        base_total_nodes += baseline_result.nodes; v2_total_nodes += v2_result.nodes;
        const double speedup = v2_result.ms > 0.0 ? baseline_result.ms / v2_result.ms : 0.0;
        const double node_delta = baseline_result.nodes > 0 ? 100.0 * (static_cast<double>(v2_result.nodes) / baseline_result.nodes - 1.0) : 0.0;
        std::cout << "  V2 time ratio:   " << std::fixed << std::setprecision(3) << speedup << "x\n";
        std::cout << "  V2 node delta:   " << std::setprecision(2) << node_delta << "%\n";
        std::cout << "  Completed depth: baseline=" << baseline_result.depth << ", v2=" << v2_result.depth << "\n";
    }

    const double base_nps = base_total_ms > 0.0 ? static_cast<double>(base_total_nodes) / (base_total_ms / 1000.0) : 0.0;
    const double v2_nps = v2_total_ms > 0.0 ? static_cast<double>(v2_total_nodes) / (v2_total_ms / 1000.0) : 0.0;
    std::cout << "\nAggregate\n"
              << "  baseline nodes: " << base_total_nodes << ", time_ms: " << std::fixed << std::setprecision(2) << base_total_ms << ", NPS: " << std::setprecision(0) << base_nps << '\n'
              << "  v2 nodes:       " << v2_total_nodes << ", time_ms: " << std::setprecision(2) << v2_total_ms << ", NPS: " << std::setprecision(0) << v2_nps << '\n'
              << "  v2 time ratio:   " << std::setprecision(3) << (v2_total_ms > 0.0 ? base_total_ms / v2_total_ms : 0.0) << "x\n"
              << "  v2 node delta:   " << std::setprecision(2) << (base_total_nodes > 0 ? 100.0 * (static_cast<double>(v2_total_nodes) / base_total_nodes - 1.0) : 0.0) << "%\n";
    return 0;
}
