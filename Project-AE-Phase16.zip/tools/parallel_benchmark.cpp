#include "chess/fen.hpp"
#include "chess/game.hpp"
#include "chess/search.hpp"
#include "chess/zobrist.hpp"
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
#include <thread>

using namespace ae::chess;

int main() {
    zobrist::init();
    const std::vector<std::string> fens = {
        "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
    };
    const unsigned hc = std::max(1u, std::thread::hardware_concurrency());
    const std::vector<unsigned> thread_counts = {1, std::min(2u, hc), std::min(4u, hc)};

    std::cout << "Project-AE Phase 8 Parallel Benchmark\n"
              << "Depth: 2\n";
    for (const unsigned threads : thread_counts) {
        double total_ms = 0.0;
        std::uint64_t total_nodes = 0;
        std::cout << "\nThreads: " << threads << '\n';
        for (const auto& fen : fens) {
            Position p;
            std::string error;
            if (!set_from_fen(p, fen, &error)) return 1;
            Searcher s;
            const auto r = s.search(p, SearchLimits{2, 0, threads});
            total_ms += r.elapsed_ms;
            total_nodes += r.nodes;
            std::cout << "  nodes=" << r.nodes << " time_ms=" << std::fixed << std::setprecision(2)
                      << r.elapsed_ms << " nps=" << std::setprecision(0) << r.nodes_per_second
                      << " best=" << move_to_uci(r.best_move) << '\n';
        }
        const double nps = total_ms > 0.0 ? total_nodes / (total_ms / 1000.0) : 0.0;
        std::cout << "  aggregate_nodes=" << total_nodes << " aggregate_time_ms="
                  << std::fixed << std::setprecision(2) << total_ms
                  << " aggregate_nps=" << std::setprecision(0) << nps << '\n';
    }
}
