#include "chess/fen.hpp"
#include "chess/search.hpp"
#include "chess/zobrist.hpp"
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

struct BenchCase { const char* name; const char* fen; };

int main() {
    using namespace ae::chess;
    zobrist::init();
    const std::vector<BenchCase> cases = {
        {"startpos", "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"},
        {"kiwipete", "r3k2r/p1ppqpb1/bn2pnp1/2pP4/1p2P3/2N2N2/PPPB1PPP/R2QKB1R w KQkq - 0 1"},
        {"middlegame", "r1bq1rk1/ppp2ppp/2n1pn2/8/2BPP3/2N1BN2/PPP2PPP/R2Q1RK1 w - - 0 1"}
    };

    constexpr int depth = 4;
    constexpr std::uint64_t node_limit = 100000;
    std::uint64_t total_nodes = 0;
    double total_ms = 0.0;
    std::cout << "Project-AE Phase 7 Benchmark\n";
    std::cout << "Depth target: " << depth << "\n"
              << "Node limit: " << node_limit << " per position\n\n";
    std::cout << std::left << std::setw(14) << "Position"
              << std::right << std::setw(12) << "Nodes"
              << std::setw(12) << "Time(ms)"
              << std::setw(14) << "NPS"
              << std::setw(12) << "TT hits"
              << std::setw(12) << "Cutoffs" << '\n';

    for (const auto& test : cases) {
        Position position;
        std::string error;
        if (!set_from_fen(position, test.fen, &error)) {
            std::cerr << test.name << ": FEN error: " << error << '\n';
            return 1;
        }
        Searcher searcher;
        const auto result = searcher.search(position, SearchLimits{depth, node_limit});
        total_nodes += result.nodes;
        total_ms += result.elapsed_ms;
        std::cout << std::left << std::setw(14) << test.name
                  << std::right << std::setw(12) << result.nodes
                  << std::setw(12) << std::fixed << std::setprecision(2) << result.elapsed_ms
                  << std::setw(14) << std::setprecision(0) << result.nodes_per_second
                  << std::setw(12) << result.metrics.tt_hits
                  << std::setw(12) << result.metrics.beta_cutoffs << '\n';
    }
    const double aggregate_nps = total_ms > 0.0 ? static_cast<double>(total_nodes) / (total_ms / 1000.0) : 0.0;
    std::cout << "\nAggregate nodes: " << total_nodes << '\n';
    std::cout << "Aggregate time:  " << std::fixed << std::setprecision(2) << total_ms << " ms\n";
    std::cout << "Aggregate NPS:   " << std::setprecision(0) << aggregate_nps << '\n';
    return 0;
}
