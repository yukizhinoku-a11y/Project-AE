#pragma once

#include "chess/types.hpp"
#include <cstdint>

namespace ae::chess {

enum class MoveFlag : std::uint8_t {
    Quiet = 0,
    DoublePawnPush = 1,
    KingCastle = 2,
    QueenCastle = 3,
    Capture = 4,
    EnPassant = 5,
    PromotionKnight = 8,
    PromotionBishop = 9,
    PromotionRook = 10,
    PromotionQueen = 11,
    PromotionKnightCapture = 12,
    PromotionBishopCapture = 13,
    PromotionRookCapture = 14,
    PromotionQueenCapture = 15
};

class Move {
public:
    constexpr Move() noexcept = default;
    constexpr Move(Square from, Square to, MoveFlag flag = MoveFlag::Quiet) noexcept
        : data_(static_cast<std::uint16_t>(square_index(from)) |
                (static_cast<std::uint16_t>(square_index(to)) << 6) |
                (static_cast<std::uint16_t>(flag) << 12)) {}

    [[nodiscard]] constexpr Square from() const noexcept {
        return static_cast<Square>(data_ & 0x3F);
    }
    [[nodiscard]] constexpr Square to() const noexcept {
        return static_cast<Square>((data_ >> 6) & 0x3F);
    }
    [[nodiscard]] constexpr MoveFlag flag() const noexcept {
        return static_cast<MoveFlag>((data_ >> 12) & 0x0F);
    }
    [[nodiscard]] constexpr std::uint16_t raw() const noexcept { return data_; }
    [[nodiscard]] constexpr explicit operator bool() const noexcept { return data_ != 0; }

    [[nodiscard]] constexpr bool is_capture() const noexcept {
        const auto f = static_cast<std::uint8_t>(flag());
        return f == 4 || f == 5 || f >= 12;
    }
    [[nodiscard]] constexpr bool is_promotion() const noexcept {
        return static_cast<std::uint8_t>(flag()) >= 8;
    }
    [[nodiscard]] constexpr PieceType promotion_piece() const noexcept {
        switch (flag()) {
            case MoveFlag::PromotionKnight:
            case MoveFlag::PromotionKnightCapture: return PieceType::Knight;
            case MoveFlag::PromotionBishop:
            case MoveFlag::PromotionBishopCapture: return PieceType::Bishop;
            case MoveFlag::PromotionRook:
            case MoveFlag::PromotionRookCapture: return PieceType::Rook;
            case MoveFlag::PromotionQueen:
            case MoveFlag::PromotionQueenCapture: return PieceType::Queen;
            default: return PieceType::None;
        }
    }

    friend constexpr bool operator==(Move a, Move b) noexcept { return a.data_ == b.data_; }
    friend constexpr bool operator!=(Move a, Move b) noexcept { return !(a == b); }

private:
    std::uint16_t data_{0};
};

} // namespace ae::chess
