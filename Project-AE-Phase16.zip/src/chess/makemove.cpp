#include "chess/makemove.hpp"

namespace ae::chess {
namespace {

void clear_castling_for_square(CastlingRights& rights, Square square) noexcept {
    const std::uint8_t current = static_cast<std::uint8_t>(rights);
    std::uint8_t clear_mask = 0;
    switch (square) {
        case Square::E1: clear_mask = static_cast<std::uint8_t>(WhiteKingSide | WhiteQueenSide); break;
        case Square::H1: clear_mask = static_cast<std::uint8_t>(WhiteKingSide); break;
        case Square::A1: clear_mask = static_cast<std::uint8_t>(WhiteQueenSide); break;
        case Square::E8: clear_mask = static_cast<std::uint8_t>(BlackKingSide | BlackQueenSide); break;
        case Square::H8: clear_mask = static_cast<std::uint8_t>(BlackKingSide); break;
        case Square::A8: clear_mask = static_cast<std::uint8_t>(BlackQueenSide); break;
        default: break;
    }
    rights = static_cast<CastlingRights>(current & static_cast<std::uint8_t>(~clear_mask));
}

bool is_valid_promotion(PieceType p) noexcept {
    return p == PieceType::Knight || p == PieceType::Bishop ||
           p == PieceType::Rook || p == PieceType::Queen;
}

} // namespace

bool make_move(Position& pos, Move move, UndoState& undo) noexcept {
    const auto moving = pos.piece_at(move.from());
    if (!moving || moving->color != pos.side_to_move()) return false;

    const Color side = pos.side_to_move();
    const Color enemy = opposite(side);
    const PieceType type = moving->type;
    const MoveFlag flag = move.flag();
    const Square from = move.from();
    const Square to = move.to();

    if (from == Square::None || to == Square::None) return false;
    if (auto target = pos.piece_at(to); target && target->color == side) return false;
    if (flag == MoveFlag::KingCastle || flag == MoveFlag::QueenCastle) {
        if (type != PieceType::King) return false;
    }
    if (flag == MoveFlag::DoublePawnPush && type != PieceType::Pawn) return false;
    if (flag == MoveFlag::EnPassant && type != PieceType::Pawn) return false;
    if (move.is_promotion() && (type != PieceType::Pawn || !is_valid_promotion(move.promotion_piece()))) return false;

    undo.castling_rights = pos.castling_rights();
    undo.en_passant_square = pos.en_passant_square();
    undo.halfmove_clock = pos.halfmove_clock();
    undo.fullmove_number = pos.fullmove_number();
    undo.key = pos.key();
    undo.captured_piece = PieceType::None;
    undo.captured_square = Square::None;

    if (auto target = pos.piece_at(to); target && target->color == enemy) {
        undo.captured_piece = target->type;
        undo.captured_square = to;
    }

    if (flag == MoveFlag::EnPassant) {
        const int captured_index = square_index(to) + (side == Color::White ? -8 : 8);
        if (to != pos.en_passant_square() || captured_index < 0 || captured_index >= 64) return false;
        const Square captured_square = static_cast<Square>(captured_index);
        const auto captured = pos.piece_at(captured_square);
        if (!captured || captured->color != enemy || captured->type != PieceType::Pawn) return false;
        undo.captured_piece = PieceType::Pawn;
        undo.captured_square = captured_square;
    }

    if (flag == MoveFlag::KingCastle || flag == MoveFlag::QueenCastle) {
        const Square rook_from = flag == MoveFlag::KingCastle
            ? (side == Color::White ? Square::H1 : Square::H8)
            : (side == Color::White ? Square::A1 : Square::A8);
        const Square rook_to = flag == MoveFlag::KingCastle
            ? (side == Color::White ? Square::F1 : Square::F8)
            : (side == Color::White ? Square::D1 : Square::D8);
        const auto rook = pos.piece_at(rook_from);
        if (!rook || rook->color != side || rook->type != PieceType::Rook) return false;
        if (pos.piece_at(rook_to)) return false;
    }

    pos.remove_piece(side, type, from);
    if (undo.captured_piece != PieceType::None)
        pos.remove_piece(enemy, undo.captured_piece, undo.captured_square);

    if (flag == MoveFlag::KingCastle || flag == MoveFlag::QueenCastle) {
        const Square rook_from = flag == MoveFlag::KingCastle
            ? (side == Color::White ? Square::H1 : Square::H8)
            : (side == Color::White ? Square::A1 : Square::A8);
        const Square rook_to = flag == MoveFlag::KingCastle
            ? (side == Color::White ? Square::F1 : Square::F8)
            : (side == Color::White ? Square::D1 : Square::D8);
        pos.remove_piece(side, PieceType::Rook, rook_from);
        pos.put_piece(side, PieceType::Rook, rook_to);
    }

    pos.put_piece(side, move.is_promotion() ? move.promotion_piece() : type, to);

    CastlingRights rights = pos.castling_rights();
    if (type == PieceType::King || type == PieceType::Rook) clear_castling_for_square(rights, from);
    if (undo.captured_piece == PieceType::Rook) clear_castling_for_square(rights, undo.captured_square);
    pos.set_castling_rights(rights);

    pos.set_en_passant_square(Square::None);
    if (type == PieceType::Pawn && flag == MoveFlag::DoublePawnPush) {
        const int ep_index = (square_index(from) + square_index(to)) / 2;
        pos.set_en_passant_square(static_cast<Square>(ep_index));
    }

    pos.set_halfmove_clock((type == PieceType::Pawn || undo.captured_piece != PieceType::None)
        ? 0 : pos.halfmove_clock() + 1);
    pos.set_fullmove_number(pos.fullmove_number() + (side == Color::Black ? 1 : 0));
    pos.set_side_to_move(enemy);
    pos.refresh_key();
    return true;
}

bool make_move(Position& pos, Move move) noexcept {
    UndoState ignored;
    return make_move(pos, move, ignored);
}

void unmake_move(Position& pos, Move move, const UndoState& undo) noexcept {
    const Color side = opposite(pos.side_to_move());
    const Color enemy = opposite(side);
    const PieceType placed = move.is_promotion() ? move.promotion_piece() : (move.flag() == MoveFlag::KingCastle || move.flag() == MoveFlag::QueenCastle ? PieceType::King : PieceType::None);

    if (placed != PieceType::None) pos.remove_piece(side, placed, move.to());

    if (move.flag() == MoveFlag::KingCastle || move.flag() == MoveFlag::QueenCastle) {
        pos.put_piece(side, PieceType::King, move.from());
        const Square rook_from = move.flag() == MoveFlag::KingCastle
            ? (side == Color::White ? Square::H1 : Square::H8)
            : (side == Color::White ? Square::A1 : Square::A8);
        const Square rook_to = move.flag() == MoveFlag::KingCastle
            ? (side == Color::White ? Square::F1 : Square::F8)
            : (side == Color::White ? Square::D1 : Square::D8);
        pos.remove_piece(side, PieceType::Rook, rook_to);
        pos.put_piece(side, PieceType::Rook, rook_from);
    } else {
        const PieceType original = move.is_promotion() ? PieceType::Pawn : pos.piece_at(move.to())->type;
        pos.remove_piece(side, original, move.to());
        pos.put_piece(side, original, move.from());
    }

    if (undo.captured_piece != PieceType::None)
        pos.put_piece(enemy, undo.captured_piece, undo.captured_square);

    pos.set_castling_rights(undo.castling_rights);
    pos.set_en_passant_square(undo.en_passant_square);
    pos.set_halfmove_clock(undo.halfmove_clock);
    pos.set_fullmove_number(undo.fullmove_number);
    pos.set_side_to_move(side);
    pos.refresh_key();
}

} // namespace ae::chess
