#pragma once
#include "chess/position.hpp"
#include <string_view>

namespace ae::chess {

bool set_from_fen(Position& pos, std::string_view fen, std::string* error = nullptr);

[[nodiscard]] std::string to_fen(const Position& pos);

} // namespace ae::chess
