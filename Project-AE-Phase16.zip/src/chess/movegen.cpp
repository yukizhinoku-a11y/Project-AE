#include "chess/movegen.hpp"
#include "chess/attacks.hpp"
#include "chess/bitboard.hpp"
#include "chess/makemove.hpp"

namespace ae::chess {
namespace {

void add_promotion_moves(MoveList& list, Square from, Square to, bool capture) noexcept {
    if (capture) {
        list.push(Move(from, to, MoveFlag::PromotionQueenCapture));
        list.push(Move(from, to, MoveFlag::PromotionRookCapture));
        list.push(Move(from, to, MoveFlag::PromotionBishopCapture));
        list.push(Move(from, to, MoveFlag::PromotionKnightCapture));
    } else {
        list.push(Move(from, to, MoveFlag::PromotionQueen));
        list.push(Move(from, to, MoveFlag::PromotionRook));
        list.push(Move(from, to, MoveFlag::PromotionBishop));
        list.push(Move(from, to, MoveFlag::PromotionKnight));
    }
}

void generate_pawns(const Position& pos, MoveList& list, Color side) noexcept {
    const Bitboard own = pos.occupancy(side);
    const Bitboard enemy = pos.occupancy(opposite(side));
    Bitboard pawns = pos.pieces(side, PieceType::Pawn);
    const int direction = side == Color::White ? 8 : -8;
    const int start_rank = side == Color::White ? 1 : 6;
    const int promotion_rank = side == Color::White ? 6 : 1;

    while (pawns) {
        const Square from = pop_lsb(pawns);
        const int from_i = square_index(from);
        const int rank = rank_of(from);
        const int file = file_of(from);

        const int one_i = from_i + direction;
        if (one_i >= 0 && one_i < 64 && !(pos.occupied() & bit(static_cast<Square>(one_i)))) {
            const Square to = static_cast<Square>(one_i);
            if (rank == promotion_rank) add_promotion_moves(list, from, to, false);
            else list.push(Move(from, to));

            if (rank == start_rank) {
                const int two_i = from_i + 2 * direction;
                if (!(pos.occupied() & bit(static_cast<Square>(two_i))))
                    list.push(Move(from, static_cast<Square>(two_i), MoveFlag::DoublePawnPush));
            }
        }

        const int capture_rank = rank + (side == Color::White ? 1 : -1);
        if (capture_rank < 0 || capture_rank > 7) continue;
        for (int df : {-1, 1}) {
            const int target_file = file + df;
            if (target_file < 0 || target_file > 7) continue;
            const Square to = static_cast<Square>(capture_rank * 8 + target_file);
            if (enemy & bit(to)) {
                if (rank == promotion_rank) add_promotion_moves(list, from, to, true);
                else list.push(Move(from, to, MoveFlag::Capture));
            } else if (to == pos.en_passant_square()) {
                list.push(Move(from, to, MoveFlag::EnPassant));
            }
        }
    }

    (void)own;
}

void generate_piece_moves(const Position& pos, MoveList& list, Color side, PieceType type) noexcept {
    const Bitboard own = pos.occupancy(side);
    const Bitboard enemy = pos.occupancy(opposite(side));
    Bitboard pieces = pos.pieces(side, type);
    while (pieces) {
        const Square from = pop_lsb(pieces);
        Bitboard targets = 0;
        switch (type) {
            case PieceType::Knight: targets = attacks::knight(from); break;
            case PieceType::Bishop: targets = attacks::bishop(from, pos.occupied()); break;
            case PieceType::Rook: targets = attacks::rook(from, pos.occupied()); break;
            case PieceType::Queen: targets = attacks::queen(from, pos.occupied()); break;
            case PieceType::King: targets = attacks::king(from); break;
            default: break;
        }
        targets &= ~own;
        while (targets) {
            const Square to = pop_lsb(targets);
            list.push(Move(from, to, (enemy & bit(to)) ? MoveFlag::Capture : MoveFlag::Quiet));
        }
    }
}

void generate_castling(const Position& pos, MoveList& list, Color side) noexcept {
    const Bitboard occupied = pos.occupied();
    const Color enemy = opposite(side);
    if (side == Color::White) {
        if ((pos.castling_rights() & WhiteKingSide) &&
            !(occupied & (bit(Square::F1) | bit(Square::G1))) &&
            !is_square_attacked(pos, Square::E1, enemy) &&
            !is_square_attacked(pos, Square::F1, enemy) &&
            !is_square_attacked(pos, Square::G1, enemy)) {
            list.push(Move(Square::E1, Square::G1, MoveFlag::KingCastle));
        }
        if ((pos.castling_rights() & WhiteQueenSide) &&
            !(occupied & (bit(Square::B1) | bit(Square::C1) | bit(Square::D1))) &&
            !is_square_attacked(pos, Square::E1, enemy) &&
            !is_square_attacked(pos, Square::D1, enemy) &&
            !is_square_attacked(pos, Square::C1, enemy)) {
            list.push(Move(Square::E1, Square::C1, MoveFlag::QueenCastle));
        }
    } else {
        if ((pos.castling_rights() & BlackKingSide) &&
            !(occupied & (bit(Square::F8) | bit(Square::G8))) &&
            !is_square_attacked(pos, Square::E8, enemy) &&
            !is_square_attacked(pos, Square::F8, enemy) &&
            !is_square_attacked(pos, Square::G8, enemy)) {
            list.push(Move(Square::E8, Square::G8, MoveFlag::KingCastle));
        }
        if ((pos.castling_rights() & BlackQueenSide) &&
            !(occupied & (bit(Square::B8) | bit(Square::C8) | bit(Square::D8))) &&
            !is_square_attacked(pos, Square::E8, enemy) &&
            !is_square_attacked(pos, Square::D8, enemy) &&
            !is_square_attacked(pos, Square::C8, enemy)) {
            list.push(Move(Square::E8, Square::C8, MoveFlag::QueenCastle));
        }
    }
}

} // namespace

bool is_square_attacked(const Position& pos, Square square, Color by) noexcept {
    const Bitboard occupied = pos.occupied();
    if (attacks::pawn(opposite(by), square) & pos.pieces(by, PieceType::Pawn)) return true;
    if (attacks::knight(square) & pos.pieces(by, PieceType::Knight)) return true;
    if (attacks::bishop(square, occupied) & (pos.pieces(by, PieceType::Bishop) | pos.pieces(by, PieceType::Queen))) return true;
    if (attacks::rook(square, occupied) & (pos.pieces(by, PieceType::Rook) | pos.pieces(by, PieceType::Queen))) return true;
    if (attacks::king(square) & pos.pieces(by, PieceType::King)) return true;
    return false;
}

MoveList generate_pseudo_legal(const Position& pos) noexcept {
    MoveList list;
    const Color side = pos.side_to_move();
    generate_pawns(pos, list, side);
    generate_piece_moves(pos, list, side, PieceType::Knight);
    generate_piece_moves(pos, list, side, PieceType::Bishop);
    generate_piece_moves(pos, list, side, PieceType::Rook);
    generate_piece_moves(pos, list, side, PieceType::Queen);
    generate_piece_moves(pos, list, side, PieceType::King);
    generate_castling(pos, list, side);
    return list;
}

MoveList generate_legal(const Position& pos) noexcept {
    MoveList legal;
    const Color side = pos.side_to_move();
    const MoveList pseudo = generate_pseudo_legal(pos);
    Position next = pos;
    for (const Move move : pseudo) {
        UndoState undo;
        if (!make_move(next, move, undo)) continue;
        const Bitboard king_bb = next.pieces(side, PieceType::King);
        const bool legal_move = king_bb && !is_square_attacked(next, lsb(king_bb), opposite(side));
        unmake_move(next, move, undo);
        if (legal_move) legal.push(move);
    }
    return legal;
}

} // namespace ae::chess
