#include "chess/evaluation.hpp"
#include "chess/attacks.hpp"
#include "chess/bitboard.hpp"
#include <array>
#include <charconv>
#include <sstream>
#include <string>

namespace ae::chess {
namespace {

constexpr std::array<int, 64> PawnTable = {
     0,   0,   0,   0,   0,   0,   0,   0,
    50,  50,  50,  50,  50,  50,  50,  50,
    10,  10,  20,  30,  30,  20,  10,  10,
     5,   5,  10,  25,  25,  10,   5,   5,
     0,   0,   0,  20,  20,   0,   0,   0,
     5,  -5, -10,   0,   0, -10,  -5,   5,
     5,  10,  10, -20, -20,  10,  10,   5,
     0,   0,   0,   0,   0,   0,   0,   0
};

constexpr std::array<int, 64> KnightTable = {
    -50, -40, -30, -30, -30, -30, -40, -50,
    -40, -20,   0,   5,   5,   0, -20, -40,
    -30,   5,  10,  15,  15,  10,   5, -30,
    -30,   0,  15,  20,  20,  15,   0, -30,
    -30,   5,  15,  20,  20,  15,   5, -30,
    -30,   0,  10,  15,  15,  10,   0, -30,
    -40, -20,   0,   0,   0,   0, -20, -40,
    -50, -40, -30, -30, -30, -30, -40, -50
};

constexpr std::array<int, 64> BishopTable = {
    -20, -10, -10, -10, -10, -10, -10, -20,
    -10,   5,   0,   0,   0,   0,   5, -10,
    -10,  10,  10,  10,  10,  10,  10, -10,
    -10,   0,  10,  10,  10,  10,   0, -10,
    -10,   5,   5,  10,  10,   5,   5, -10,
    -10,   0,   5,  10,  10,   5,   0, -10,
    -10,   0,   0,   0,   0,   0,   0, -10,
    -20, -10, -10, -10, -10, -10, -10, -20
};

constexpr std::array<int, 64> RookTable = {
     0,   0,   0,   5,   5,   0,   0,   0,
    -5,   0,   0,   0,   0,   0,   0,  -5,
    -5,   0,   0,   0,   0,   0,   0,  -5,
    -5,   0,   0,   0,   0,   0,   0,  -5,
    -5,   0,   0,   0,   0,   0,   0,  -5,
    -5,   0,   0,   0,   0,   0,   0,  -5,
     5,  10,  10,  10,  10,  10,  10,   5,
     0,   0,   0,   0,   0,   0,   0,   0
};

constexpr std::array<int, 64> QueenTable = {
    -20, -10, -10,   0,   0, -10, -10, -20,
    -10,   0,   0,   0,   0,   0,   0, -10,
    -10,   0,   5,   5,   5,   5,   0, -10,
      0,   0,   5,   5,   5,   5,   0,  -5,
      0,   0,   5,   5,   5,   5,   0,  -5,
    -10,   0,   5,   5,   5,   5,   0, -10,
    -10,   0,   0,   0,   0,   0,   0, -10,
    -20, -10, -10,   0,   0, -10, -10, -20
};

constexpr std::array<int, 64> KingTable = {
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -20, -30, -30, -40, -40, -30, -30, -20,
    -10, -20, -20, -20, -20, -20, -20, -10,
     20,  20,   0,   0,   0,   0,  20,  20,
     20,  30,  10,   0,   0,  10,  30,  20
};

constexpr Bitboard file_mask(int file) noexcept { return FILE_A << file; }

constexpr Bitboard adjacent_files(int file) noexcept {
    Bitboard result = 0;
    if (file > 0) result |= file_mask(file - 1);
    if (file < 7) result |= file_mask(file + 1);
    return result;
}

constexpr Square mirrored_square(Square square) noexcept {
    return static_cast<Square>(square_index(square) ^ 56);
}

const std::array<int, 64>& piece_table(const EvaluationParams& params, PieceType type) noexcept {
    switch (type) {
        case PieceType::Pawn: return params.pawn_table;
        case PieceType::Knight: return params.knight_table;
        case PieceType::Bishop: return params.bishop_table;
        case PieceType::Rook: return params.rook_table;
        case PieceType::Queen: return params.queen_table;
        case PieceType::King: return params.king_table;
        default: return params.pawn_table;
    }
}

int piece_value(const EvaluationParams& params, PieceType type) noexcept {
    switch (type) {
        case PieceType::Pawn: return params.pawn_value;
        case PieceType::Knight: return params.knight_value;
        case PieceType::Bishop: return params.bishop_value;
        case PieceType::Rook: return params.rook_value;
        case PieceType::Queen: return params.queen_value;
        case PieceType::King: return params.king_value;
        default: return 0;
    }
}

int positional_score(const Position& pos, Color side, const EvaluationParams& params) noexcept {
    int score = 0;
    for (int p = 0; p < PIECE_TYPE_COUNT; ++p) {
        const PieceType type = static_cast<PieceType>(p);
        Bitboard pieces = pos.pieces(side, type);
        const auto& table = piece_table(params, type);
        while (pieces) {
            const Square square = pop_lsb(pieces);
            const Square index_square = side == Color::White ? square : mirrored_square(square);
            score += table[square_index(index_square)];
        }
    }
    return score;
}

int pawn_structure_score(const Position& pos, Color side, const EvaluationParams& params) noexcept {
    const Color enemy = opposite(side);
    const Bitboard pawns = pos.pieces(side, PieceType::Pawn);
    const Bitboard enemy_pawns = pos.pieces(enemy, PieceType::Pawn);
    int score = 0;

    for (int file = 0; file < 8; ++file) {
        const Bitboard own_file = pawns & file_mask(file);
        const int own_count = popcount(own_file);
        if (own_count > 1) score -= params.doubled_pawn_penalty * (own_count - 1);
        if (own_file && !(pawns & adjacent_files(file))) score -= params.isolated_pawn_penalty;
    }

    Bitboard scan = pawns;
    while (scan) {
        const Square square = pop_lsb(scan);
        const int file = file_of(square);
        const int rank = rank_of(square);
        const Bitboard relevant_enemy = enemy_pawns & (file_mask(file) | adjacent_files(file));
        bool passed = true;
        Bitboard enemy_scan = relevant_enemy;
        while (enemy_scan) {
            const Square enemy_square = pop_lsb(enemy_scan);
            const int enemy_rank = rank_of(enemy_square);
            if ((side == Color::White && enemy_rank > rank) ||
                (side == Color::Black && enemy_rank < rank)) {
                passed = false;
                break;
            }
        }
        if (passed) {
            const int advancement = side == Color::White ? rank : 7 - rank;
            score += params.passed_pawn_base + advancement * params.passed_pawn_advance;
        }
    }
    return score;
}

int mobility_score(const Position& pos, Color side, const EvaluationParams& params) noexcept {
    const Bitboard occupied = pos.occupied();
    const Bitboard own = pos.occupancy(side);
    int score = 0;

    Bitboard pieces = pos.pieces(side, PieceType::Knight);
    while (pieces) score += popcount(attacks::knight(pop_lsb(pieces)) & ~own) * params.knight_mobility;
    pieces = pos.pieces(side, PieceType::Bishop);
    while (pieces) score += popcount(attacks::bishop(pop_lsb(pieces), occupied) & ~own) * params.bishop_mobility;
    pieces = pos.pieces(side, PieceType::Rook);
    while (pieces) score += popcount(attacks::rook(pop_lsb(pieces), occupied) & ~own) * params.rook_mobility;
    pieces = pos.pieces(side, PieceType::Queen);
    while (pieces) score += popcount(attacks::queen(pop_lsb(pieces), occupied) & ~own) * params.queen_mobility;
    return score;
}

int king_safety_score(const Position& pos, Color side, const EvaluationParams& params) noexcept {
    const Bitboard king_bb = pos.pieces(side, PieceType::King);
    if (!king_bb) return 0;
    const Square king = lsb(king_bb);
    const int file = file_of(king);
    const int rank = rank_of(king);
    const Bitboard own_pawns = pos.pieces(side, PieceType::Pawn);
    int score = 0;

    const int forward = side == Color::White ? 1 : -1;
    const int shield_rank = rank + forward;
    if (shield_rank >= 0 && shield_rank < 8) {
        for (int f = file - 1; f <= file + 1; ++f) {
            if (f < 0 || f > 7) continue;
            if (own_pawns & bit(static_cast<Square>(shield_rank * 8 + f))) score += params.pawn_shield_bonus;
            else score -= params.pawn_shield_missing_penalty;
        }
    }
    if (file >= 2 && file <= 5) score -= params.central_king_penalty;
    return score;
}

int bishop_pair_score(const Position& pos, Color side, const EvaluationParams& params) noexcept {
    return popcount(pos.pieces(side, PieceType::Bishop)) >= 2 ? params.bishop_pair_bonus : 0;
}

void set_error(std::string* error, const char* message) {
    if (error) *error = message;
}

} // namespace

EvaluationParams EvaluationParams::default_v1() noexcept {
    EvaluationParams params;
    params.pawn_table = PawnTable;
    params.knight_table = KnightTable;
    params.bishop_table = BishopTable;
    params.rook_table = RookTable;
    params.queen_table = QueenTable;
    params.king_table = KingTable;
    return params;
}

bool EvaluationParams::is_valid() const noexcept {
    return pawn_value >= 0 && knight_value >= 0 && bishop_value >= 0 &&
           rook_value >= 0 && queen_value >= 0 && king_value >= 0 &&
           doubled_pawn_penalty >= 0 && isolated_pawn_penalty >= 0 &&
           passed_pawn_base >= 0 && passed_pawn_advance >= 0 &&
           knight_mobility >= 0 && bishop_mobility >= 0 && rook_mobility >= 0 &&
           queen_mobility >= 0 && pawn_shield_bonus >= 0 &&
           pawn_shield_missing_penalty >= 0 && central_king_penalty >= 0 &&
           bishop_pair_bonus >= 0;
}

std::string EvaluationParams::to_text() const {
    std::ostringstream out;
    out << "version=1\n";
    out << "pawn_value=" << pawn_value << '\n';
    out << "knight_value=" << knight_value << '\n';
    out << "bishop_value=" << bishop_value << '\n';
    out << "rook_value=" << rook_value << '\n';
    out << "queen_value=" << queen_value << '\n';
    out << "king_value=" << king_value << '\n';
    out << "doubled_pawn_penalty=" << doubled_pawn_penalty << '\n';
    out << "isolated_pawn_penalty=" << isolated_pawn_penalty << '\n';
    out << "passed_pawn_base=" << passed_pawn_base << '\n';
    out << "passed_pawn_advance=" << passed_pawn_advance << '\n';
    out << "knight_mobility=" << knight_mobility << '\n';
    out << "bishop_mobility=" << bishop_mobility << '\n';
    out << "rook_mobility=" << rook_mobility << '\n';
    out << "queen_mobility=" << queen_mobility << '\n';
    out << "pawn_shield_bonus=" << pawn_shield_bonus << '\n';
    out << "pawn_shield_missing_penalty=" << pawn_shield_missing_penalty << '\n';
    out << "central_king_penalty=" << central_king_penalty << '\n';
    out << "bishop_pair_bonus=" << bishop_pair_bonus << '\n';
    const std::array<std::pair<const char*, const std::array<int, 64>*>, 6> tables = {{
        {"pawn_table", &pawn_table}, {"knight_table", &knight_table},
        {"bishop_table", &bishop_table}, {"rook_table", &rook_table},
        {"queen_table", &queen_table}, {"king_table", &king_table}
    }};
    for (const auto& [name, table] : tables) {
        out << name << '=';
        for (std::size_t i = 0; i < table->size(); ++i) {
            if (i) out << ',';
            out << (*table)[i];
        }
        out << '\n';
    }
    return out.str();
}

bool EvaluationParams::from_text(std::string_view text, EvaluationParams& out, std::string* error) {
    EvaluationParams candidate = default_v1();
    std::istringstream input{std::string(text)};
    std::string line;
    bool saw_version = false;

    auto fail = [&](const char* message) {
        set_error(error, message);
        return false;
    };
    auto parse_int = [](const std::string& value, int& target) -> bool {
        const char* begin = value.data();
        const char* end = begin + value.size();
        const auto [ptr, ec] = std::from_chars(begin, end, target);
        return ec == std::errc{} && ptr == end;
    };

    while (std::getline(input, line)) {
        if (line.empty()) continue;
        const auto eq = line.find('=');
        if (eq == std::string::npos) return fail("invalid parameter line");
        const std::string key = line.substr(0, eq);
        const std::string value = line.substr(eq + 1);

        if (key == "version") {
            if (value != "1") return fail("unsupported parameter version");
            saw_version = true;
            continue;
        }

        int* scalar = nullptr;
        if (key == "pawn_value") scalar = &candidate.pawn_value;
        else if (key == "knight_value") scalar = &candidate.knight_value;
        else if (key == "bishop_value") scalar = &candidate.bishop_value;
        else if (key == "rook_value") scalar = &candidate.rook_value;
        else if (key == "queen_value") scalar = &candidate.queen_value;
        else if (key == "king_value") scalar = &candidate.king_value;
        else if (key == "doubled_pawn_penalty") scalar = &candidate.doubled_pawn_penalty;
        else if (key == "isolated_pawn_penalty") scalar = &candidate.isolated_pawn_penalty;
        else if (key == "passed_pawn_base") scalar = &candidate.passed_pawn_base;
        else if (key == "passed_pawn_advance") scalar = &candidate.passed_pawn_advance;
        else if (key == "knight_mobility") scalar = &candidate.knight_mobility;
        else if (key == "bishop_mobility") scalar = &candidate.bishop_mobility;
        else if (key == "rook_mobility") scalar = &candidate.rook_mobility;
        else if (key == "queen_mobility") scalar = &candidate.queen_mobility;
        else if (key == "pawn_shield_bonus") scalar = &candidate.pawn_shield_bonus;
        else if (key == "pawn_shield_missing_penalty") scalar = &candidate.pawn_shield_missing_penalty;
        else if (key == "central_king_penalty") scalar = &candidate.central_king_penalty;
        else if (key == "bishop_pair_bonus") scalar = &candidate.bishop_pair_bonus;

        if (scalar) {
            if (!parse_int(value, *scalar)) return fail("invalid parameter value");
            continue;
        }

        std::array<int, 64>* table = nullptr;
        if (key == "pawn_table") table = &candidate.pawn_table;
        else if (key == "knight_table") table = &candidate.knight_table;
        else if (key == "bishop_table") table = &candidate.bishop_table;
        else if (key == "rook_table") table = &candidate.rook_table;
        else if (key == "queen_table") table = &candidate.queen_table;
        else if (key == "king_table") table = &candidate.king_table;
        else return fail("unknown parameter name");

        std::stringstream values(value);
        std::string token;
        std::size_t i = 0;
        while (std::getline(values, token, ',')) {
            if (i >= table->size()) return fail("too many table values");
            int parsed = 0;
            if (!parse_int(token, parsed)) return fail("invalid parameter value");
            (*table)[i++] = parsed;
        }
        if (i != table->size()) return fail("wrong table length");
    }

    if (!saw_version) return fail("missing parameter version");
    if (!candidate.is_valid()) return fail("parameter values out of range");
    out = candidate;
    return true;
}

int evaluate_material(const Position& pos, const EvaluationParams& params) noexcept {
    int score = 0;
    for (int p = 0; p < PIECE_TYPE_COUNT; ++p) {
        const PieceType type = static_cast<PieceType>(p);
        const int value = piece_value(params, type);
        score += popcount(pos.pieces(Color::White, type)) * value;
        score -= popcount(pos.pieces(Color::Black, type)) * value;
    }
    return score;
}

int evaluate_material(const Position& pos) noexcept {
    static const EvaluationParams params = EvaluationParams::default_v1();
    return evaluate_material(pos, params);
}

int evaluate(const Position& pos, const EvaluationParams& params) noexcept {
    int score = evaluate_material(pos, params);
    score += positional_score(pos, Color::White, params);
    score -= positional_score(pos, Color::Black, params);
    score += pawn_structure_score(pos, Color::White, params);
    score -= pawn_structure_score(pos, Color::Black, params);
    score += mobility_score(pos, Color::White, params);
    score -= mobility_score(pos, Color::Black, params);
    score += king_safety_score(pos, Color::White, params);
    score -= king_safety_score(pos, Color::Black, params);
    score += bishop_pair_score(pos, Color::White, params);
    score -= bishop_pair_score(pos, Color::Black, params);
    return score;
}

int evaluate(const Position& pos) noexcept {
    static const EvaluationParams params = EvaluationParams::default_v1();
    return evaluate(pos, params);
}

} // namespace ae::chess
