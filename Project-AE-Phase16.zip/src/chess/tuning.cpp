#include "chess/tuning.hpp"
#include "chess/fen.hpp"
#include "chess/selfplay.hpp"
#include "chess/search.hpp"
#include "chess/zobrist.hpp"
#include <chrono>
#include <cmath>
#include <random>
#include <sstream>

namespace ae::chess {
namespace {
constexpr std::string_view StartFen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

bool set_scalar(EvaluationParams& p, std::string_view n, int v) {
    if (n == "pawn_value") p.pawn_value = v;
    else if (n == "knight_value") p.knight_value = v;
    else if (n == "bishop_value") p.bishop_value = v;
    else if (n == "rook_value") p.rook_value = v;
    else if (n == "queen_value") p.queen_value = v;
    else if (n == "king_value") p.king_value = v;
    else if (n == "doubled_pawn_penalty") p.doubled_pawn_penalty = v;
    else if (n == "isolated_pawn_penalty") p.isolated_pawn_penalty = v;
    else if (n == "passed_pawn_base") p.passed_pawn_base = v;
    else if (n == "passed_pawn_advance") p.passed_pawn_advance = v;
    else if (n == "knight_mobility") p.knight_mobility = v;
    else if (n == "bishop_mobility") p.bishop_mobility = v;
    else if (n == "rook_mobility") p.rook_mobility = v;
    else if (n == "queen_mobility") p.queen_mobility = v;
    else if (n == "pawn_shield_bonus") p.pawn_shield_bonus = v;
    else if (n == "pawn_shield_missing_penalty") p.pawn_shield_missing_penalty = v;
    else if (n == "central_king_penalty") p.central_king_penalty = v;
    else if (n == "bishop_pair_bonus") p.bishop_pair_bonus = v;
    else return false;
    return true;
}

SelfPlayGame play_match_game(const EvaluationParams& baseline,
                             const EvaluationParams& candidate,
                             const TuningConfig& config,
                             bool candidate_white,
                             std::uint64_t seed) {
    zobrist::init();
    Position start;
    std::string error;
    if (!set_from_fen(start, StartFen, &error)) return {};

    SelfPlayGame output;
    output.game.reset(start);
    Searcher white(candidate_white ? candidate : baseline);
    Searcher black(candidate_white ? baseline : candidate);
    std::mt19937_64 rng(seed);
    const auto begin = std::chrono::steady_clock::now();

    for (int ply = 0; ply < config.max_plies; ++ply) {
        const GameResult current = output.game.result();
        if (current != GameResult::Ongoing) break;

        SearchLimits limits{config.depth, config.node_limit, config.threads};
        Searcher& searcher = output.game.position().side_to_move() == Color::White ? white : black;
        const SearchResult result = searcher.search(output.game.position(), limits);
        output.nodes += result.nodes;

        Move move = result.best_move;
        if (move == Move{}) {
            const MoveList legal = generate_legal(output.game.position());
            if (legal.size() == 0) break;
            move = legal[0];
        } else if (config.randomize_equal_moves) {
            // Deterministic randomization is intentionally conservative in v1:
            // only replace an invalid/empty search choice, not a scored move.
            (void)rng;
        }

        if (!output.game.play(move)) break;
    }

    output.plies = static_cast<int>(output.game.ply());
    output.result = output.game.result();
    if (output.result == GameResult::Ongoing && output.plies >= config.max_plies)
        output.result = GameResult::Draw;
    output.elapsed_ms = std::chrono::duration<double, std::milli>(
        std::chrono::steady_clock::now() - begin).count();
    return output;
}
} // namespace


MatchStatistics MatchSummary::statistics(double z) const noexcept {
    MatchStatistics stats;
    if (games == 0 || z < 0.0) return stats;

    // Each game contributes a score in {0, 0.5, 1}. This uses the sample
    // variance of those per-game scores, so draws are represented directly.
    double sum = 0.0;
    double sum_sq = 0.0;
    for (const MatchGameResult& game : game_results) {
        double score = 0.0;
        if (game.result == GameResult::Draw) score = 0.5;
        else if ((game.candidate_white && game.result == GameResult::WhiteWin) ||
                 (!game.candidate_white && game.result == GameResult::BlackWin)) score = 1.0;
        sum += score;
        sum_sq += score * score;
    }

    const double n = static_cast<double>(game_results.size());
    stats.mean_score = n > 0.0 ? sum / n : 0.0;
    if (n > 1.0) {
        const double variance = std::max(0.0, (sum_sq - (sum * sum) / n) / (n - 1.0));
        stats.standard_error = std::sqrt(variance / n);
    }
    const double margin = z * stats.standard_error;
    stats.confidence_low = std::max(0.0, stats.mean_score - margin);
    stats.confidence_high = std::min(1.0, stats.mean_score + margin);
    stats.statistically_above_baseline = stats.confidence_low > 0.5;
    stats.statistically_below_baseline = stats.confidence_high < 0.5;
    return stats;
}

double MatchSummary::candidate_score() const noexcept {
    if (games == 0) return 0.0;
    return (static_cast<double>(candidate_wins) + 0.5 * static_cast<double>(draws)) /
           static_cast<double>(games);
}

double MatchSummary::candidate_score_percent() const noexcept {
    return candidate_score() * 100.0;
}

bool apply_parameter_change(EvaluationParams& params, const ParameterChange& change,
                            std::string* error) {
    if (!set_scalar(params, change.name, change.value)) {
        if (error) *error = "unknown parameter: " + change.name;
        return false;
    }
    if (!params.is_valid()) {
        if (error) *error = "parameter set is invalid after changing " + change.name;
        return false;
    }
    return true;
}

MatchSummary run_tuning_match(const EvaluationParams& baseline,
                              const EvaluationParams& candidate,
                              const TuningConfig& config) {
    MatchSummary summary;
    if (config.games == 0 || config.depth < 1 || config.max_plies < 1 ||
        config.threads == 0 || !baseline.is_valid() || !candidate.is_valid()) return summary;

    summary.games = config.games;
    summary.game_results.reserve(config.games);
    for (unsigned i = 0; i < config.games; ++i) {
        const bool candidate_white = (i % 2 == 0);
        const auto game = play_match_game(baseline, candidate, config,
                                          candidate_white, config.seed + i);
        MatchGameResult result;
        result.result = game.result;
        result.candidate_white = candidate_white;
        result.nodes = game.nodes;
        result.elapsed_ms = game.elapsed_ms;
        result.plies = game.plies;
        if (config.write_pgn) result.pgn = game_to_pgn(game, static_cast<int>(i + 1));
        summary.nodes += result.nodes;
        summary.elapsed_ms += result.elapsed_ms;

        if (game.result == GameResult::Draw) ++summary.draws;
        else if ((candidate_white && game.result == GameResult::WhiteWin) ||
                 (!candidate_white && game.result == GameResult::BlackWin)) ++summary.candidate_wins;
        else if (game.result == GameResult::WhiteWin || game.result == GameResult::BlackWin) ++summary.baseline_wins;
        summary.game_results.push_back(std::move(result));
    }
    return summary;
}

std::vector<ExperimentResult> run_tuning_experiments(
    const EvaluationParams& baseline,
    const std::vector<ExperimentCandidate>& candidates,
    const TuningConfig& config,
    std::string* error) {
    std::vector<ExperimentResult> results;
    if (!baseline.is_valid()) {
        if (error) *error = "baseline parameter set is invalid";
        return results;
    }
    if (candidates.empty()) return results;
    if (config.games == 0 || config.depth < 1 || config.max_plies < 1 || config.threads == 0) {
        if (error) *error = "invalid tuning configuration";
        return results;
    }

    results.reserve(candidates.size());
    for (std::size_t i = 0; i < candidates.size(); ++i) {
        EvaluationParams candidate = baseline;
        for (const ParameterChange& change : candidates[i].changes) {
            std::string local_error;
            if (!apply_parameter_change(candidate, change, &local_error)) {
                if (error) {
                    *error = "candidate '" + candidates[i].label + "': " + local_error;
                }
                return {};
            }
        }

        TuningConfig candidate_config = config;
        // Give every experiment a deterministic, non-overlapping seed stream.
        candidate_config.seed = config.seed + static_cast<std::uint64_t>(i) * 1000003ULL;
        ExperimentResult result;
        result.label = candidates[i].label;
        result.changes = candidates[i].changes;
        result.summary = run_tuning_match(baseline, candidate, candidate_config);
        result.statistics = result.summary.statistics();
        results.push_back(std::move(result));
    }
    return results;
}

} // namespace ae::chess
