#include "chess/perft.hpp"
#include "chess/makemove.hpp"
#include "chess/movegen.hpp"

namespace ae::chess {

std::uint64_t perft(const Position& pos, int depth) noexcept {
    if (depth <= 0) return 1;
    const MoveList moves = generate_legal(pos);
    if (depth == 1) return static_cast<std::uint64_t>(moves.size());

    Position next = pos;
    std::uint64_t nodes = 0;
    for (const Move move : moves) {
        UndoState undo;
        if (make_move(next, move, undo)) {
            nodes += perft(next, depth - 1);
            unmake_move(next, move, undo);
        }
    }
    return nodes;
}

} // namespace ae::chess
