#pragma once

#include "chess/types.hpp"

namespace ae::chess::attacks {

[[nodiscard]] Bitboard pawn(Color side, Square square) noexcept;
[[nodiscard]] Bitboard knight(Square square) noexcept;
[[nodiscard]] Bitboard king(Square square) noexcept;
[[nodiscard]] Bitboard bishop(Square square, Bitboard occupied) noexcept;
[[nodiscard]] Bitboard rook(Square square, Bitboard occupied) noexcept;
[[nodiscard]] Bitboard queen(Square square, Bitboard occupied) noexcept;

} // namespace ae::chess::attacks
