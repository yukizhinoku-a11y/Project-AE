#pragma once

#include "chess/move.hpp"
#include "chess/position.hpp"
#include <array>
#include <cstddef>

namespace ae::chess {

class MoveList {
public:
    static constexpr std::size_t MaxMoves = 256;

    void push(Move move) noexcept { moves_[size_++] = move; }
    [[nodiscard]] constexpr std::size_t size() const noexcept { return size_; }
    [[nodiscard]] constexpr Move operator[](std::size_t i) const noexcept { return moves_[i]; }
    [[nodiscard]] constexpr Move* begin() noexcept { return moves_.data(); }
    [[nodiscard]] constexpr Move* end() noexcept { return moves_.data() + size_; }
    [[nodiscard]] constexpr const Move* begin() const noexcept { return moves_.data(); }
    [[nodiscard]] constexpr const Move* end() const noexcept { return moves_.data() + size_; }

private:
    std::array<Move, MaxMoves> moves_{};
    std::size_t size_{0};
};

[[nodiscard]] bool is_square_attacked(const Position& pos, Square square, Color by) noexcept;
[[nodiscard]] MoveList generate_pseudo_legal(const Position& pos) noexcept;
[[nodiscard]] MoveList generate_legal(const Position& pos) noexcept;

} // namespace ae::chess
