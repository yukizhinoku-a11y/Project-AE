#pragma once

#include "chess/types.hpp"

namespace ae::chess {

constexpr Bitboard FILE_A = 0x0101010101010101ULL;
constexpr Bitboard FILE_H = 0x8080808080808080ULL;
constexpr Bitboard RANK_1 = 0x00000000000000FFULL;
constexpr Bitboard RANK_8 = 0xFF00000000000000ULL;

constexpr int popcount(Bitboard b) noexcept {
    int count = 0;
    while (b) {
        b &= (b - 1);
        ++count;
    }
    return count;
}
constexpr bool more_than_one(Bitboard b) noexcept { return b && (b & (b - 1)); }
constexpr Square lsb(Bitboard b) noexcept {
    if (!b) return Square::None;
    int index = 0;
    while ((b & 1ULL) == 0ULL) {
        b >>= 1;
        ++index;
    }
    return static_cast<Square>(index);
}
constexpr Square pop_lsb(Bitboard& b) noexcept {
    const Square s = lsb(b);
    if (b) b &= (b - 1);
    return s;
}

} // namespace ae::chess
