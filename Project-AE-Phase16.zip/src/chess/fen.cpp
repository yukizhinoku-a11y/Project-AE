#include "chess/fen.hpp"
#include "chess/zobrist.hpp"
#include <charconv>
#include <sstream>
#include <string>
#include <vector>
#include <array>

namespace ae::chess {
namespace {

bool decode_piece(char c, Color& color, PieceType& type) {
    color = (c >= 'A' && c <= 'Z') ? Color::White : Color::Black;
    const char x = static_cast<char>(c | 32);
    switch (x) {
        case 'p': type = PieceType::Pawn; return true;
        case 'n': type = PieceType::Knight; return true;
        case 'b': type = PieceType::Bishop; return true;
        case 'r': type = PieceType::Rook; return true;
        case 'q': type = PieceType::Queen; return true;
        case 'k': type = PieceType::King; return true;
        default: return false;
    }
}

bool parse_int(std::string_view s, int& out) {
    if (s.empty()) return false;
    const char* begin = s.data();
    const char* end = begin + s.size();
    auto [ptr, ec] = std::from_chars(begin, end, out);
    return ec == std::errc{} && ptr == end;
}

} // namespace

bool set_from_fen(Position& pos, std::string_view fen, std::string* error) {
    std::istringstream stream{std::string(fen)};
    std::vector<std::string> fields;
    for (std::string s; stream >> s;) fields.push_back(s);
    if (fields.size() != 6) {
        if (error) *error = "FEN must contain exactly 6 fields";
        return false;
    }

    Position next;
    int rank = 7;
    int file = 0;
    for (char c : fields[0]) {
        if (c == '/') {
            if (file != 8 || rank == 0) {
                if (error) *error = "invalid board rows in FEN";
                return false;
            }
            --rank;
            file = 0;
            continue;
        }
        if (c >= '1' && c <= '8') {
            file += c - '0';
            if (file > 8) {
                if (error) *error = "too many squares in rank";
                return false;
            }
            continue;
        }
        Color color{};
        PieceType type{};
        if (!decode_piece(c, color, type) || file >= 8) {
            if (error) *error = "invalid piece placement";
            return false;
        }
        next.put_piece(color, type, static_cast<Square>(rank * 8 + file));
        ++file;
    }
    if (rank != 0 || file != 8) {
        if (error) *error = "incomplete board in FEN";
        return false;
    }

    if (fields[1] == "w") next.set_side_to_move(Color::White);
    else if (fields[1] == "b") next.set_side_to_move(Color::Black);
    else {
        if (error) *error = "invalid side-to-move field";
        return false;
    }

    CastlingRights rights = NoCastling;
    if (fields[2] != "-") {
        for (char c : fields[2]) {
            switch (c) {
                case 'K': rights |= WhiteKingSide; break;
                case 'Q': rights |= WhiteQueenSide; break;
                case 'k': rights |= BlackKingSide; break;
                case 'q': rights |= BlackQueenSide; break;
                default:
                    if (error) *error = "invalid castling field";
                    return false;
            }
        }
    }
    next.set_castling_rights(rights);

    if (fields[3] == "-") {
        next.set_en_passant_square(Square::None);
    } else {
        if (fields[3].size() != 2 || fields[3][0] < 'a' || fields[3][0] > 'h' ||
            (fields[3][1] != '3' && fields[3][1] != '6')) {
            if (error) *error = "invalid en-passant field";
            return false;
        }
        const int ep_file = fields[3][0] - 'a';
        const int ep_rank = fields[3][1] - '1';
        next.set_en_passant_square(static_cast<Square>(ep_rank * 8 + ep_file));
    }

    int halfmove = 0;
    int fullmove = 0;
    if (!parse_int(fields[4], halfmove) || !parse_int(fields[5], fullmove) || halfmove < 0 || fullmove < 1) {
        if (error) *error = "invalid move counters";
        return false;
    }
    next.set_halfmove_clock(halfmove);
    next.set_fullmove_number(fullmove);

    std::string consistency;
    if (!next.is_consistent(&consistency)) {
        if (error) *error = consistency;
        return false;
    }

    next.refresh_key();
    pos = next;
    return true;
}

std::string to_fen(const Position& pos) {
    std::string out;
    for (int rank = 7; rank >= 0; --rank) {
        int empty = 0;
        for (int file = 0; file < 8; ++file) {
            const Square sq = static_cast<Square>(rank * 8 + file);
            const auto piece = pos.piece_at(sq);
            if (!piece) { ++empty; continue; }
            if (empty) { out += std::to_string(empty); empty = 0; }
            char c = '?';
            switch (piece->type) {
                case PieceType::Pawn: c = 'p'; break;
                case PieceType::Knight: c = 'n'; break;
                case PieceType::Bishop: c = 'b'; break;
                case PieceType::Rook: c = 'r'; break;
                case PieceType::Queen: c = 'q'; break;
                case PieceType::King: c = 'k'; break;
                default: break;
            }
            if (piece->color == Color::White) c = static_cast<char>(c - ('a' - 'A'));
            out.push_back(c);
        }
        if (empty) out += std::to_string(empty);
        if (rank != 0) out.push_back('/');
    }
    out += pos.side_to_move() == Color::White ? " w " : " b ";
    const auto rights = static_cast<std::uint8_t>(pos.castling_rights());
    if (rights == 0) out.push_back('-');
    else {
        if (rights & WhiteKingSide) out.push_back('K');
        if (rights & WhiteQueenSide) out.push_back('Q');
        if (rights & BlackKingSide) out.push_back('k');
        if (rights & BlackQueenSide) out.push_back('q');
    }
    out.push_back(' ');
    out += square_name(pos.en_passant_square());
    out.push_back(' ');
    out += std::to_string(pos.halfmove_clock());
    out.push_back(' ');
    out += std::to_string(pos.fullmove_number());
    return out;
}

} // namespace ae::chess
