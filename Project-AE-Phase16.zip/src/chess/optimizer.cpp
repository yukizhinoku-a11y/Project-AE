#include "chess/optimizer.hpp"
#include <algorithm>
#include <limits>

namespace ae::chess {
namespace {

bool read_scalar(const EvaluationParams& p, const std::string& n, int& v) noexcept {
    if (n == "pawn_value") v = p.pawn_value;
    else if (n == "knight_value") v = p.knight_value;
    else if (n == "bishop_value") v = p.bishop_value;
    else if (n == "rook_value") v = p.rook_value;
    else if (n == "queen_value") v = p.queen_value;
    else if (n == "king_value") v = p.king_value;
    else if (n == "doubled_pawn_penalty") v = p.doubled_pawn_penalty;
    else if (n == "isolated_pawn_penalty") v = p.isolated_pawn_penalty;
    else if (n == "passed_pawn_base") v = p.passed_pawn_base;
    else if (n == "passed_pawn_advance") v = p.passed_pawn_advance;
    else if (n == "knight_mobility") v = p.knight_mobility;
    else if (n == "bishop_mobility") v = p.bishop_mobility;
    else if (n == "rook_mobility") v = p.rook_mobility;
    else if (n == "queen_mobility") v = p.queen_mobility;
    else if (n == "pawn_shield_bonus") v = p.pawn_shield_bonus;
    else if (n == "pawn_shield_missing_penalty") v = p.pawn_shield_missing_penalty;
    else if (n == "central_king_penalty") v = p.central_king_penalty;
    else if (n == "bishop_pair_bonus") v = p.bishop_pair_bonus;
    else return false;
    return true;
}

} // namespace

int parameter_value(const EvaluationParams& params, const std::string& name, bool* found) noexcept {
    int value = 0;
    const bool ok = read_scalar(params, name, value);
    if (found) *found = ok;
    return value;
}

const char* optimization_decision_name(OptimizationDecision decision) noexcept {
    switch (decision) {
        case OptimizationDecision::Improved: return "improved";
        case OptimizationDecision::Rejected: return "rejected";
        case OptimizationDecision::Inconclusive: return "inconclusive";
    }
    return "inconclusive";
}

bool optimize_parameters(EvaluationParams& best_params,
                         const std::vector<SearchParameter>& parameters,
                         const TuningConfig& config,
                         OptimizationResult& result,
                         std::string* error) {
    result = {};
    result.best_params = best_params;

    if (!best_params.is_valid()) {
        if (error) *error = "initial parameter set is invalid";
        return false;
    }
    if (parameters.empty()) {
        if (error) *error = "no search parameters supplied";
        return false;
    }
    if (config.games == 0 || config.depth < 1 || config.max_plies < 1 || config.threads == 0) {
        if (error) *error = "invalid tuning configuration";
        return false;
    }

    for (const SearchParameter& parameter : parameters) {
        if (parameter.step <= 0) {
            if (error) *error = "search step must be positive for " + parameter.name;
            return false;
        }
        bool found = false;
        const int start = parameter_value(best_params, parameter.name, &found);
        if (!found) {
            if (error) *error = "unknown search parameter: " + parameter.name;
            return false;
        }

        OptimizationStep step;
        step.parameter = parameter.name;
        step.starting_value = start;
        step.selected_value = start;

        // Coordinate search: test one step below and one step above the current value.
        // A move is accepted only when the candidate's 95% CI is entirely above 50%.
        const int directions[2] = {-1, 1};
        double best_score = -1.0;
        int best_value = start;
        bool found_statistical_improvement = false;

        for (int direction : directions) {
            const long long proposed_ll = static_cast<long long>(start) +
                                           static_cast<long long>(direction) * parameter.step;
            if (proposed_ll < 0 || proposed_ll > std::numeric_limits<int>::max()) continue;
            const int proposed = static_cast<int>(proposed_ll);

            EvaluationParams candidate = best_params;
            std::string apply_error;
            if (!apply_parameter_change(candidate, {parameter.name, proposed}, &apply_error)) {
                if (error) *error = apply_error;
                return false;
            }

            TuningConfig candidate_config = config;
            // Separate each parameter/direction experiment deterministically.
            const std::uint64_t ordinal = static_cast<std::uint64_t>(result.steps.size()) * 2ULL +
                                           static_cast<std::uint64_t>(direction == 1 ? 1 : 0);
            candidate_config.seed = config.seed + ordinal * 1000003ULL;
            const MatchSummary summary = run_tuning_match(best_params, candidate, candidate_config);
            const MatchStatistics statistics = summary.statistics();

            OptimizationCandidateResult candidate_result;
            candidate_result.parameter = parameter.name;
            candidate_result.value = proposed;
            candidate_result.summary = summary;
            candidate_result.statistics = statistics;
            if (statistics.statistically_above_baseline) {
                candidate_result.decision = OptimizationDecision::Improved;
                found_statistical_improvement = true;
                const double score = summary.candidate_score();
                if (score > best_score || (score == best_score && proposed < best_value)) {
                    best_score = score;
                    best_value = proposed;
                }
            } else if (statistics.statistically_below_baseline) {
                candidate_result.decision = OptimizationDecision::Rejected;
            } else {
                candidate_result.decision = OptimizationDecision::Inconclusive;
            }
            step.candidates.push_back(std::move(candidate_result));
        }

        if (found_statistical_improvement && best_value != start) {
            std::string apply_error;
            if (!apply_parameter_change(best_params, {parameter.name, best_value}, &apply_error)) {
                if (error) *error = apply_error;
                return false;
            }
            step.selected_value = best_value;
            ++result.accepted_changes;
        }

        result.steps.push_back(std::move(step));
        result.best_params = best_params;
    }

    return true;
}

} // namespace ae::chess
