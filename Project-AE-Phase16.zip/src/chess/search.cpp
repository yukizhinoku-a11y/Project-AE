#include "chess/search.hpp"
#include "chess/evaluation.hpp"
#include "chess/bitboard.hpp"
#include "chess/makemove.hpp"
#include "chess/movegen.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <thread>

namespace ae::chess {
namespace {
constexpr int PieceValue[PIECE_TYPE_COUNT] = {100, 320, 330, 500, 900, 20000};
}

Searcher::Searcher(EvaluationParams params) : tt_(TTSize), eval_params_(std::move(params)) {}

bool Searcher::should_stop() noexcept {
    if (limits_.node_limit != 0 && nodes_ >= limits_.node_limit) {
        stopped_ = true;
        return true;
    }
    return false;
}

bool Searcher::in_check(const Position& position, Color side) const noexcept {
    const Bitboard king = position.pieces(side, PieceType::King);
    return king && is_square_attacked(position, lsb(king), opposite(side));
}

int Searcher::terminal_score(bool check, int ply) noexcept {
    if (!check) return 0;
    return -MateScore + ply;
}

Searcher::TTEntry& Searcher::tt_entry(HashKey key) noexcept {
    return tt_[static_cast<std::size_t>(key) & (TTSize - 1)];
}

int Searcher::score_to_tt(int score, int ply) noexcept {
    if (score > MateScore - MaxPly) return score + ply;
    if (score < -MateScore + MaxPly) return score - ply;
    return score;
}

int Searcher::score_from_tt(int score, int ply) noexcept {
    if (score > MateScore - MaxPly) return score - ply;
    if (score < -MateScore + MaxPly) return score + ply;
    return score;
}

void Searcher::store_tt(HashKey key, Move best_move, int depth, int score,
                        TTBound bound, int ply) noexcept {
    TTEntry& entry = tt_entry(key);
    if (entry.key != key || depth >= entry.depth || bound == TTBound::Exact) {
        entry.key = key;
        entry.best_move = best_move;
        entry.score = score_to_tt(score, ply);
        entry.depth = static_cast<std::int16_t>(depth);
        entry.bound = bound;
    }
}

int Searcher::move_order_score(const Position& position, Move move, Move tt_move, int ply) const noexcept {
    if (move == tt_move && tt_move) return 1'000'000;

    if (move.is_capture()) {
        const auto attacker = position.piece_at(move.from());
        const auto victim = position.piece_at(move.to());
        int victim_value = victim ? PieceValue[static_cast<int>(victim->type)] : PieceValue[static_cast<int>(PieceType::Pawn)];
        if (move.flag() == MoveFlag::EnPassant) victim_value = PieceValue[static_cast<int>(PieceType::Pawn)];
        const int attacker_value = attacker ? PieceValue[static_cast<int>(attacker->type)] : 0;
        return 500'000 + victim_value * 16 - attacker_value;
    }

    if (move.is_promotion()) return 450'000 + PieceValue[static_cast<int>(move.promotion_piece())];

    if (ply < MaxPly) {
        if (move == killers_[ply][0]) return 400'000;
        if (move == killers_[ply][1]) return 390'000;
    }

    const Color side = position.side_to_move();
    return history_[static_cast<int>(side)][square_index(move.from())][square_index(move.to())];
}

void Searcher::order_moves(const Position& position, MoveList& moves, Move tt_move, int ply) const noexcept {
    std::array<std::pair<int, Move>, MoveList::MaxMoves> scored{};
    for (std::size_t i = 0; i < moves.size(); ++i) {
        scored[i] = {move_order_score(position, moves[i], tt_move, ply), moves[i]};
    }
    std::sort(scored.begin(), scored.begin() + moves.size(),
              [](const auto& a, const auto& b) { return a.first > b.first; });
    for (std::size_t i = 0; i < moves.size(); ++i) moves[i] = scored[i].second;
}

void Searcher::record_killer(Move move, int ply) noexcept {
    if (ply >= MaxPly || move.is_capture()) return;
    if (killers_[ply][0] == move) return;
    killers_[ply][1] = killers_[ply][0];
    killers_[ply][0] = move;
}

void Searcher::record_history(Color side, Move move, int depth) noexcept {
    if (move.is_capture() || depth <= 0) return;
    int& value = history_[static_cast<int>(side)][square_index(move.from())][square_index(move.to())];
    value += depth * depth;
    if (value > 1'000'000) value = 1'000'000;
}

int Searcher::quiescence(Position& position, int alpha, int beta, int ply) {
    if (should_stop() || ply >= MaxPly) return evaluate(position, eval_params_) *
        (position.side_to_move() == Color::White ? 1 : -1);
    ++nodes_;
    ++metrics_.quiescence_nodes;

    const Color side = position.side_to_move();
    const bool check = in_check(position, side);
    MoveList legal = generate_legal(position);

    if (legal.size() == 0) return terminal_score(check, ply);

    if (!check) {
        const int stand_pat = evaluate_position(position) * (side == Color::White ? 1 : -1);
        if (stand_pat >= beta) return stand_pat;
        alpha = std::max(alpha, stand_pat);

        // Quiescence only searches captures/promotions when not in check. Avoid
        // sorting quiet legal moves that will never be searched.
        MoveList tactical;
        for (const Move move : legal) {
            if (move.is_capture() || move.is_promotion()) tactical.push(move);
        }
        order_moves(position, tactical, Move{}, ply);

        for (const Move move : tactical) {
            UndoState undo;
            if (!make_move(position, move, undo)) continue;
            const int score = -quiescence(position, -beta, -alpha, ply + 1);
            unmake_move(position, move, undo);
            if (stopped_) return 0;
            if (score >= beta) return score;
            alpha = std::max(alpha, score);
        }
        return alpha;
    }

    order_moves(position, legal, Move{}, ply);
    for (const Move move : legal) {
        UndoState undo;
        if (!make_move(position, move, undo)) continue;
        const int score = -quiescence(position, -beta, -alpha, ply + 1);
        unmake_move(position, move, undo);
        if (stopped_) return 0;
        if (score >= beta) return score;
        alpha = std::max(alpha, score);
    }
    return alpha;
}

int Searcher::negamax(Position& position, int depth, int alpha, int beta, int ply,
                      std::vector<Move>& pv) {
    if (should_stop()) return 0;
    ++nodes_;
    const HashKey key = position.key();
    ++metrics_.tt_probes;
    const int original_alpha = alpha;
    const int original_beta = beta;
    Move tt_move{};
    TTEntry& entry = tt_entry(key);
    if (entry.key == key && entry.bound != TTBound::None) {
        ++metrics_.tt_hits;
        tt_move = entry.best_move;
        if (entry.depth >= depth) {
            const int tt_score = score_from_tt(entry.score, ply);
            if (entry.bound == TTBound::Exact) {
                ++metrics_.tt_cutoffs;
                pv.clear(); if (tt_move) pv.push_back(tt_move); return tt_score;
            }
            if (entry.bound == TTBound::Lower) alpha = std::max(alpha, tt_score);
            else if (entry.bound == TTBound::Upper) beta = std::min(beta, tt_score);
            if (alpha >= beta) { ++metrics_.tt_cutoffs; return tt_score; }
        }
    }
    if (depth <= 0) return quiescence(position, alpha, beta, ply);
    const Color side = position.side_to_move();
    const bool check = in_check(position, side);
    const bool has_non_pawn_piece =
        position.pieces(side, PieceType::Knight) || position.pieces(side, PieceType::Bishop) ||
        position.pieces(side, PieceType::Rook) || position.pieces(side, PieceType::Queen);
    if (limits_.options.use_null_move && !check && depth >= 5 && has_non_pawn_piece && beta < MateScore - MaxPly) {
        ++metrics_.null_move_searches;
        const Color saved_side = position.side_to_move();
        const Square saved_ep = position.en_passant_square();
        const int saved_halfmove = position.halfmove_clock();
        const int saved_fullmove = position.fullmove_number();
        position.set_side_to_move(opposite(saved_side));
        position.set_en_passant_square(Square::None);
        position.set_halfmove_clock(saved_halfmove + 1);
        position.set_fullmove_number(saved_fullmove + (saved_side == Color::Black ? 1 : 0));
        position.refresh_key();
        std::vector<Move> null_pv;
        const int reduction = 3;
        const int null_score = -negamax(position, depth - 1 - reduction, -beta, -beta + 1, ply + 1, null_pv);
        position.set_side_to_move(saved_side);
        position.set_en_passant_square(saved_ep);
        position.set_halfmove_clock(saved_halfmove);
        position.set_fullmove_number(saved_fullmove);
        position.refresh_key();
        if (stopped_) return 0;
        if (null_score >= beta) { ++metrics_.null_move_cutoffs; return null_score; }
    }
    MoveList legal = generate_legal(position);
    metrics_.generated_moves += legal.size();
    if (legal.size() == 0) return terminal_score(check, ply);
    ++metrics_.ordered_nodes;
    order_moves(position, legal, tt_move, ply);
    int best_score = -Infinity; Move best_move{}; std::vector<Move> child_pv; bool first_move = true; std::size_t move_index = 0;
    for (const Move move : legal) {
        UndoState undo; if (!make_move(position, move, undo)) continue; child_pv.clear();
        int score = -Infinity; const bool quiet = !move.is_capture() && !move.is_promotion(); const bool late = move_index >= 3; int reduction = 0;
        if (limits_.options.use_lmr && !first_move && quiet && late && depth >= 3) { reduction = move_index >= 8 ? 2 : 1; ++metrics_.lmr_reductions; }
        if (first_move || !limits_.options.use_pvs) {
            score = -negamax(position, depth - 1, -beta, -alpha, ply + 1, child_pv);
        } else {
            ++metrics_.pvs_searches;
            const int reduced_depth = std::max(0, depth - 1 - reduction);
            score = -negamax(position, reduced_depth, -alpha - 1, -alpha, ply + 1, child_pv);
            if (!stopped_ && score > alpha) {
                child_pv.clear();
                score = -negamax(position, depth - 1, -beta, -alpha, ply + 1, child_pv);
            }
        }
        unmake_move(position, move, undo); if (stopped_) return 0;
        if (score > best_score) { best_score = score; best_move = move; pv.clear(); pv.push_back(move); pv.insert(pv.end(), child_pv.begin(), child_pv.end()); }
        if (score > alpha) alpha = score;
        if (alpha >= beta) { ++metrics_.beta_cutoffs; record_killer(move, ply); record_history(side, move, depth); break; }
        first_move = false; ++move_index;
    }
    TTBound bound = TTBound::Exact;
    if (best_score <= original_alpha) bound = TTBound::Upper; else if (best_score >= original_beta) bound = TTBound::Lower;
    store_tt(key, best_move, depth, best_score, bound, ply);
    return best_score;
}

SearchResult Searcher::search_fixed_depth(const Position& position, int depth) {
    SearchResult result;
    limits_.depth = std::max(1, depth);
    limits_.node_limit = 0;
    nodes_ = 0;
    stopped_ = false;
    pv_.clear();
    metrics_ = {};
    std::fill(tt_.begin(), tt_.end(), TTEntry{});
    for (auto& killers : killers_) killers = {};
    for (auto& side : history_) for (auto& from : side) from.fill(0);

    Position work = position;
    std::vector<Move> current_pv;
    const int score = negamax(work, limits_.depth, -Infinity, Infinity, 0, current_pv);
    if (!stopped_) {
        result.score = score;
        result.depth = limits_.depth;
        if (!current_pv.empty()) {
            result.best_move = current_pv.front();
            result.principal_variation = std::move(current_pv);
        }
    }
    result.nodes = nodes_;
    metrics_.nodes = nodes_;
    result.metrics = metrics_;
    return result;
}

SearchResult Searcher::search(const Position& position, SearchLimits limits) {
    limits_ = limits;
    if (limits_.depth < 1) limits_.depth = 1;
    if (limits_.threads < 1) limits_.threads = 1;
    nodes_ = 0;
    stopped_ = false;
    pv_.clear();
    metrics_ = {};
    const auto start_time = std::chrono::steady_clock::now();
    std::fill(tt_.begin(), tt_.end(), TTEntry{});
    for (auto& killers : killers_) killers = {};
    for (auto& side : history_) for (auto& from : side) from.fill(0);

    SearchResult result;
    result.threads = limits_.threads;
    Position work = position;
    const MoveList legal = generate_legal(work);
    if (legal.size() == 0) {
        result.score = terminal_score(in_check(work, work.side_to_move()), 0);
        result.depth = 0;
        const auto elapsed = std::chrono::steady_clock::now() - start_time;
        result.elapsed_ms = std::chrono::duration<double, std::milli>(elapsed).count();
        return result;
    }

    // A node budget is a single-search resource. Keep its exact semantics on the
    // reference path instead of attempting to divide it among independent workers.
    const bool use_parallel = limits_.threads > 1 && limits_.depth > 1 && limits_.node_limit == 0;

    // Single-threaded search remains the reference path.
    if (!use_parallel) {
        int previous_score = 0;
        for (int depth = 1; depth <= limits_.depth; ++depth) {
            int alpha = -Infinity; int beta = Infinity;
            constexpr int AspirationWindow = 32;
            if (limits_.options.use_aspiration && depth >= 4 && previous_score > -MateScore + MaxPly && previous_score < MateScore - MaxPly) {
                alpha = std::max(-Infinity, previous_score - AspirationWindow);
                beta = std::min(Infinity, previous_score + AspirationWindow);
            }
            std::vector<Move> current_pv;
            int score = negamax(work, depth, alpha, beta, 0, current_pv);
            if (stopped_) break;
            if (score <= alpha || score >= beta) {
                ++metrics_.aspiration_failures; current_pv.clear();
                score = negamax(work, depth, -Infinity, Infinity, 0, current_pv);
                if (stopped_) break;
            }
            if (!current_pv.empty()) { result.best_move=current_pv.front(); result.principal_variation=current_pv; result.score=score; result.depth=depth; previous_score=score; }
        }
    } else {
        // Root-split parallelism with a bounded worker count. Each worker owns its
        // Searcher/TT/history/killer state, so no shared mutable search state exists.
        struct RootResult {
            Move move{};
            int score{-Infinity};
            std::vector<Move> pv{};
            SearchMetrics metrics{};
            std::uint64_t nodes{0};
            bool valid{false};
        };

        const std::size_t move_count = legal.size();
        const unsigned worker_count = std::min<unsigned>(
            limits_.threads, static_cast<unsigned>(move_count));
        std::vector<RootResult> results(move_count);
        std::atomic<std::size_t> next_index{0};
        std::vector<std::thread> workers;
        workers.reserve(worker_count);

        for (unsigned worker_id = 0; worker_id < worker_count; ++worker_id) {
            workers.emplace_back([&]() {
                Searcher worker(eval_params_);
                while (true) {
                    const std::size_t index = next_index.fetch_add(1, std::memory_order_relaxed);
                    if (index >= move_count) break;

                    const Move root_move = legal[index];
                    Position child = work;
                    UndoState undo;
                    if (!make_move(child, root_move, undo)) continue;

                    // Search exactly the remaining depth once. The parent root move
                    // accounts for the ply consumed by make_move().
                    const SearchResult child_result =
                        worker.search_fixed_depth(child, limits_.depth - 1);

                    RootResult rr;
                    rr.move = root_move;
                    rr.score = -child_result.score;
                    rr.pv.push_back(root_move);
                    rr.pv.insert(rr.pv.end(), child_result.principal_variation.begin(),
                                 child_result.principal_variation.end());
                    rr.metrics = child_result.metrics;
                    rr.nodes = child_result.nodes;
                    rr.valid = true;
                    results[index] = std::move(rr);
                }
            });
        }

        for (auto& worker : workers) worker.join();

        bool have_result = false;
        for (const RootResult& rr : results) {
            if (!rr.valid) continue;
            nodes_ += rr.nodes;
            metrics_.nodes += rr.nodes;
            metrics_.quiescence_nodes += rr.metrics.quiescence_nodes;
            metrics_.eval_calls += rr.metrics.eval_calls;
            metrics_.tt_probes += rr.metrics.tt_probes;
            metrics_.tt_hits += rr.metrics.tt_hits;
            metrics_.tt_cutoffs += rr.metrics.tt_cutoffs;
            metrics_.beta_cutoffs += rr.metrics.beta_cutoffs;
            metrics_.generated_moves += rr.metrics.generated_moves;
            metrics_.ordered_nodes += rr.metrics.ordered_nodes;
            metrics_.null_move_searches += rr.metrics.null_move_searches;
            metrics_.null_move_cutoffs += rr.metrics.null_move_cutoffs;
            metrics_.lmr_reductions += rr.metrics.lmr_reductions;
            metrics_.pvs_searches += rr.metrics.pvs_searches;
            metrics_.aspiration_failures += rr.metrics.aspiration_failures;

            // Results are stored in root move order, so strict '>' preserves the
            // same deterministic tie-break as a sequential root search.
            if (!have_result || rr.score > result.score) {
                have_result = true;
                result.best_move = rr.move;
                result.score = rr.score;
                result.principal_variation = rr.pv;
                result.depth = limits_.depth;
            }
        }
    }

    result.nodes = nodes_;
    metrics_.nodes = nodes_;
    result.metrics = metrics_;
    const auto elapsed = std::chrono::steady_clock::now() - start_time;
    result.elapsed_ms = std::chrono::duration<double, std::milli>(elapsed).count();
    result.nodes_per_second = result.elapsed_ms > 0.0
        ? static_cast<double>(result.nodes) / (result.elapsed_ms / 1000.0)
        : 0.0;
    return result;
}

int Searcher::evaluate_position(const Position& position) noexcept {
    ++metrics_.eval_calls;
    return evaluate(position, eval_params_);
}

} // namespace ae::chess
