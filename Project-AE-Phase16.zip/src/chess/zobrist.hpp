#pragma once
#include "chess/types.hpp"
#include <array>

namespace ae::chess::zobrist {

extern std::array<std::array<std::array<HashKey,64>, PIECE_TYPE_COUNT>, 2> piece;
extern std::array<HashKey, 16> castling;
extern std::array<HashKey, 8> en_passant_file;
extern HashKey side;

void init() noexcept;

} // namespace ae::chess::zobrist
