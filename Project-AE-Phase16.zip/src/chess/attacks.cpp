#include "chess/attacks.hpp"
#include "chess/bitboard.hpp"

namespace ae::chess::attacks {
namespace {

constexpr bool on_board(int file, int rank) noexcept {
    return file >= 0 && file < 8 && rank >= 0 && rank < 8;
}

Bitboard leaper(Square square, const int (*deltas)[2], int count) noexcept {
    if (square == Square::None) return 0;
    const int file = file_of(square);
    const int rank = rank_of(square);
    Bitboard result = 0;
    for (int i = 0; i < count; ++i) {
        const int f = file + deltas[i][0];
        const int r = rank + deltas[i][1];
        if (on_board(f, r)) result |= bit(static_cast<Square>(r * 8 + f));
    }
    return result;
}

Bitboard slider(Square square, Bitboard occupied, const int (*directions)[2], int count) noexcept {
    if (square == Square::None) return 0;
    const int file = file_of(square);
    const int rank = rank_of(square);
    Bitboard result = 0;
    for (int i = 0; i < count; ++i) {
        int f = file + directions[i][0];
        int r = rank + directions[i][1];
        while (on_board(f, r)) {
            const Square target = static_cast<Square>(r * 8 + f);
            result |= bit(target);
            if (occupied & bit(target)) break;
            f += directions[i][0];
            r += directions[i][1];
        }
    }
    return result;
}

} // namespace

Bitboard pawn(Color side, Square square) noexcept {
    if (square == Square::None) return 0;
    const int file = file_of(square);
    const int rank = rank_of(square);
    const int dr = side == Color::White ? 1 : -1;
    const int target_rank = rank + dr;
    if (target_rank < 0 || target_rank > 7) return 0;

    Bitboard result = 0;
    if (file > 0) result |= bit(static_cast<Square>(target_rank * 8 + file - 1));
    if (file < 7) result |= bit(static_cast<Square>(target_rank * 8 + file + 1));
    return result;
}

Bitboard knight(Square square) noexcept {
    constexpr int deltas[8][2] = {
        {1, 2}, {2, 1}, {2, -1}, {1, -2},
        {-1, -2}, {-2, -1}, {-2, 1}, {-1, 2}
    };
    return leaper(square, deltas, 8);
}

Bitboard king(Square square) noexcept {
    constexpr int deltas[8][2] = {
        {1, 1}, {1, 0}, {1, -1}, {0, 1},
        {0, -1}, {-1, 1}, {-1, 0}, {-1, -1}
    };
    return leaper(square, deltas, 8);
}

Bitboard bishop(Square square, Bitboard occupied) noexcept {
    constexpr int directions[4][2] = {{1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
    return slider(square, occupied, directions, 4);
}

Bitboard rook(Square square, Bitboard occupied) noexcept {
    constexpr int directions[4][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    return slider(square, occupied, directions, 4);
}

Bitboard queen(Square square, Bitboard occupied) noexcept {
    return bishop(square, occupied) | rook(square, occupied);
}

} // namespace ae::chess::attacks
