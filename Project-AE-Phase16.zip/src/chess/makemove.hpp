#pragma once

#include "chess/move.hpp"
#include "chess/position.hpp"

namespace ae::chess {

struct UndoState {
    CastlingRights castling_rights{NoCastling};
    Square en_passant_square{Square::None};
    int halfmove_clock{0};
    int fullmove_number{1};
    HashKey key{0};
    PieceType captured_piece{PieceType::None};
    Square captured_square{Square::None};
};

[[nodiscard]] bool make_move(Position& pos, Move move, UndoState& undo) noexcept;
[[nodiscard]] bool make_move(Position& pos, Move move) noexcept;
void unmake_move(Position& pos, Move move, const UndoState& undo) noexcept;

} // namespace ae::chess
