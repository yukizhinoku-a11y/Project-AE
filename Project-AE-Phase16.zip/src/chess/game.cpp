#include "chess/game.hpp"
#include "chess/bitboard.hpp"
#include <algorithm>
#include <cctype>

namespace ae::chess {
namespace {

char promotion_char(PieceType p) noexcept {
    switch (p) {
        case PieceType::Knight: return 'n';
        case PieceType::Bishop: return 'b';
        case PieceType::Rook: return 'r';
        case PieceType::Queen: return 'q';
        default: return '\0';
    }
}

char piece_char(PieceType p) noexcept {
    switch (p) {
        case PieceType::Pawn: return 'P';
        case PieceType::Knight: return 'N';
        case PieceType::Bishop: return 'B';
        case PieceType::Rook: return 'R';
        case PieceType::Queen: return 'Q';
        case PieceType::King: return 'K';
        default: return '?';
    }
}


} // namespace

std::string move_to_uci(Move move) {
    if (!move) return "0000";
    std::string out;
    const auto from = square_name(move.from());
    const auto to = square_name(move.to());
    out.reserve(5);
    out.append(from);
    out.append(to);
    if (move.is_promotion()) out.push_back(promotion_char(move.promotion_piece()));
    return out;
}

bool move_from_uci(const Position& pos, std::string_view text, Move& out) noexcept {
    if (text.size() < 4 || text.size() > 5) return false;
    const char ff = static_cast<char>(std::tolower(static_cast<unsigned char>(text[0])));
    const char fr = text[1];
    const char tf = static_cast<char>(std::tolower(static_cast<unsigned char>(text[2])));
    const char tr = text[3];
    if (ff < 'a' || ff > 'h' || tf < 'a' || tf > 'h' || fr < '1' || fr > '8' || tr < '1' || tr > '8') return false;
    const Square from = static_cast<Square>((fr - '1') * 8 + (ff - 'a'));
    const Square to = static_cast<Square>((tr - '1') * 8 + (tf - 'a'));
    const MoveList legal = generate_legal(pos);
    for (const Move move : legal) {
        if (move.from() != from || move.to() != to) continue;
        if (move.is_promotion()) {
            if (text.size() != 5) continue;
            const char p = static_cast<char>(std::tolower(static_cast<unsigned char>(text[4])));
            if (promotion_char(move.promotion_piece()) != p) continue;
        } else if (text.size() != 4) {
            continue;
        }
        out = move;
        return true;
    }
    return false;
}

std::string move_to_san(const Position& pos, Move move) {
    const auto piece = pos.piece_at(move.from());
    if (!piece) return "?";
    if (move.flag() == MoveFlag::KingCastle) return "O-O";
    if (move.flag() == MoveFlag::QueenCastle) return "O-O-O";

    std::string san;
    const bool capture = move.is_capture();
    const auto legal = generate_legal(pos);

    if (piece->type != PieceType::Pawn) {
        san.push_back(piece_char(piece->type));
        bool same_file = false;
        bool same_rank = false;
        bool ambiguous = false;
        for (const Move other : legal) {
            if (other == move || other.to() != move.to()) continue;
            const auto other_piece = pos.piece_at(other.from());
            if (!other_piece || other_piece->type != piece->type) continue;
            ambiguous = true;
            same_file |= file_of(other.from()) == file_of(move.from());
            same_rank |= rank_of(other.from()) == rank_of(move.from());
        }
        if (ambiguous) {
            if (!same_file) san.push_back(static_cast<char>('a' + file_of(move.from())));
            else if (!same_rank) san.push_back(static_cast<char>('1' + rank_of(move.from())));
            else san.append(square_name(move.from()));
        }
    } else if (capture) {
        san.push_back(static_cast<char>('a' + file_of(move.from())));
    }

    if (capture) san.push_back('x');
    san.append(square_name(move.to()));
    if (move.is_promotion()) {
        san.push_back('=');
        san.push_back(piece_char(move.promotion_piece()));
    }

    Position next = pos;
    UndoState undo;
    if (make_move(next, move, undo)) {
        const auto enemy = next.side_to_move();
        const auto king_bb = next.pieces(enemy, PieceType::King);
        if (king_bb && is_square_attacked(next, lsb(king_bb), opposite(enemy))) {
            if (generate_legal(next).size() == 0) san.push_back('#');
            else san.push_back('+');
        }
    }
    return san;
}

Game::Game() {
    reset();
}

Game::Game(const Position& initial) {
    reset(initial);
}

void Game::reset(const Position& initial) {
    position_ = initial;
    moves_.clear();
    undos_.clear();
    history_keys_.clear();
    history_keys_.push_back(position_.key());
}

bool Game::play(Move move) noexcept {
    const MoveList legal = generate_legal(position_);
    if (std::find(legal.begin(), legal.end(), move) == legal.end()) return false;
    UndoState undo;
    if (!make_move(position_, move, undo)) return false;
    moves_.push_back(move);
    undos_.push_back(undo);
    history_keys_.push_back(position_.key());
    return true;
}

bool Game::play_uci(std::string_view uci) noexcept {
    Move move;
    if (!move_from_uci(position_, uci, move)) return false;
    return play(move);
}

bool Game::undo() noexcept {
    if (moves_.empty()) return false;
    const Move move = moves_.back();
    const UndoState undo = undos_.back();
    moves_.pop_back();
    undos_.pop_back();
    history_keys_.pop_back();
    unmake_move(position_, move, undo);
    return true;
}

bool Game::is_threefold_repetition() const noexcept {
    if (history_keys_.empty()) return false;
    const HashKey current = position_.key();
    int count = 0;
    for (auto it = history_keys_.rbegin(); it != history_keys_.rend(); ++it) {
        if (*it == current) ++count;
        if (count >= 3) return true;
    }
    return false;
}

bool Game::is_fifty_move_draw() const noexcept {
    return position_.halfmove_clock() >= 100;
}

bool Game::is_insufficient_material() const noexcept {
    if (position_.pieces(Color::White, PieceType::Pawn) || position_.pieces(Color::Black, PieceType::Pawn) ||
        position_.pieces(Color::White, PieceType::Rook) || position_.pieces(Color::Black, PieceType::Rook) ||
        position_.pieces(Color::White, PieceType::Queen) || position_.pieces(Color::Black, PieceType::Queen)) return false;

    const int wn = popcount(position_.pieces(Color::White, PieceType::Knight));
    const int bn = popcount(position_.pieces(Color::Black, PieceType::Knight));
    const int wb = popcount(position_.pieces(Color::White, PieceType::Bishop));
    const int bb = popcount(position_.pieces(Color::Black, PieceType::Bishop));
    const int minors = wn + bn + wb + bb;
    if (minors == 0) return true;
    if (minors == 1) return true;
    if (minors != 2 || wn != 0 || bn != 0 || wb != 1 || bb != 1) return false;

    const Square w = lsb(position_.pieces(Color::White, PieceType::Bishop));
    const Square b = lsb(position_.pieces(Color::Black, PieceType::Bishop));
    return (file_of(w) + rank_of(w)) % 2 == (file_of(b) + rank_of(b)) % 2;
}

bool Game::is_checkmate() const noexcept {
    const auto king = position_.pieces(position_.side_to_move(), PieceType::King);
    return king && is_square_attacked(position_, lsb(king), opposite(position_.side_to_move())) && generate_legal(position_).size() == 0;
}

bool Game::is_stalemate() const noexcept {
    const auto king = position_.pieces(position_.side_to_move(), PieceType::King);
    return king && !is_square_attacked(position_, lsb(king), opposite(position_.side_to_move())) && generate_legal(position_).size() == 0;
}

GameResult Game::result() const noexcept {
    if (is_checkmate()) return position_.side_to_move() == Color::White ? GameResult::BlackWin : GameResult::WhiteWin;
    if (is_stalemate() || is_threefold_repetition() || is_fifty_move_draw() || is_insufficient_material()) return GameResult::Draw;
    return GameResult::Ongoing;
}

std::string game_result_string(GameResult result) {
    switch (result) {
        case GameResult::WhiteWin: return "1-0";
        case GameResult::BlackWin: return "0-1";
        case GameResult::Draw: return "1/2-1/2";
        default: return "*";
    }
}

} // namespace ae::chess
