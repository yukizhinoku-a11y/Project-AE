#pragma once

#include "chess/types.hpp"
#include <array>
#include <optional>
#include <string>

namespace ae::chess {

class Position {
public:
    Position();

    void clear() noexcept;
    void put_piece(Color color, PieceType type, Square square) noexcept;
    void remove_piece(Color color, PieceType type, Square square) noexcept;
    [[nodiscard]] std::optional<Piece> piece_at(Square square) const noexcept;

    void set_side_to_move(Color c) noexcept { side_to_move_ = c; }
    void set_castling_rights(CastlingRights c) noexcept { castling_rights_ = c; }
    void set_en_passant_square(Square s) noexcept { en_passant_square_ = s; }
    void set_halfmove_clock(int n) noexcept { halfmove_clock_ = n; }
    void set_fullmove_number(int n) noexcept { fullmove_number_ = n; }

    [[nodiscard]] Bitboard pieces(Color c, PieceType p) const noexcept;
    [[nodiscard]] Bitboard occupancy(Color c) const noexcept;
    [[nodiscard]] Bitboard occupied() const noexcept;
    [[nodiscard]] Color side_to_move() const noexcept { return side_to_move_; }
    [[nodiscard]] CastlingRights castling_rights() const noexcept { return castling_rights_; }
    [[nodiscard]] Square en_passant_square() const noexcept { return en_passant_square_; }
    [[nodiscard]] int halfmove_clock() const noexcept { return halfmove_clock_; }
    [[nodiscard]] int fullmove_number() const noexcept { return fullmove_number_; }
    [[nodiscard]] HashKey key() const noexcept { return key_; }

    [[nodiscard]] HashKey compute_key() const noexcept;
    void refresh_key() noexcept { key_ = compute_key(); }
    [[nodiscard]] bool is_consistent(std::string* reason = nullptr) const noexcept;

private:
    std::array<std::array<Bitboard, PIECE_TYPE_COUNT>, 2> pieces_{};
    Color side_to_move_{Color::White};
    CastlingRights castling_rights_{NoCastling};
    Square en_passant_square_{Square::None};
    int halfmove_clock_{0};
    int fullmove_number_{1};
    HashKey key_{0};
};

} // namespace ae::chess
