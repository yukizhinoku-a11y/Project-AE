#pragma once

#include "chess/makemove.hpp"
#include "chess/movegen.hpp"
#include <cstddef>
#include <string>
#include <vector>

namespace ae::chess {

enum class GameResult {
    Ongoing,
    WhiteWin,
    BlackWin,
    Draw
};

class Game {
public:
    Game();
    explicit Game(const Position& initial);

    [[nodiscard]] const Position& position() const noexcept { return position_; }
    [[nodiscard]] std::size_t ply() const noexcept { return moves_.size(); }
    [[nodiscard]] const std::vector<Move>& moves() const noexcept { return moves_; }
    [[nodiscard]] GameResult result() const noexcept;
    [[nodiscard]] bool is_threefold_repetition() const noexcept;
    [[nodiscard]] bool is_fifty_move_draw() const noexcept;
    [[nodiscard]] bool is_insufficient_material() const noexcept;
    [[nodiscard]] bool is_checkmate() const noexcept;
    [[nodiscard]] bool is_stalemate() const noexcept;

    bool play(Move move) noexcept;
    bool play_uci(std::string_view uci) noexcept;
    bool undo() noexcept;

    void reset(const Position& initial = Position());

private:
    Position position_{};
    std::vector<Move> moves_{};
    std::vector<UndoState> undos_{};
    std::vector<HashKey> history_keys_{};
};

[[nodiscard]] std::string move_to_uci(Move move);
[[nodiscard]] bool move_from_uci(const Position& pos, std::string_view text, Move& out) noexcept;
[[nodiscard]] std::string move_to_san(const Position& pos, Move move);
[[nodiscard]] std::string game_result_string(GameResult result);

} // namespace ae::chess
