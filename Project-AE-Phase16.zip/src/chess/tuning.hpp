#pragma once

#include "chess/evaluation.hpp"
#include "chess/game.hpp"
#include <cstdint>
#include <string>
#include <vector>
#include <string_view>

namespace ae::chess {

struct TuningConfig {
    int depth{2};
    std::uint64_t node_limit{0};
    unsigned threads{1};
    int max_plies{80};
    unsigned games{10};
    std::uint64_t seed{1};
    bool randomize_equal_moves{false};
    bool write_pgn{false};
    std::string pgn_path{"tuning_games.pgn"};
};

struct MatchGameResult {
    GameResult result{GameResult::Ongoing};
    bool candidate_white{true};
    std::uint64_t nodes{0};
    double elapsed_ms{0.0};
    int plies{0};
    std::string pgn{};
};

struct MatchStatistics {
    double mean_score{0.0};
    double standard_error{0.0};
    double confidence_low{0.0};
    double confidence_high{0.0};
    bool statistically_above_baseline{false};
    bool statistically_below_baseline{false};

    [[nodiscard]] bool is_inconclusive() const noexcept {
        return !statistically_above_baseline && !statistically_below_baseline;
    }
};

struct MatchSummary {
    unsigned games{0};
    unsigned candidate_wins{0};
    unsigned baseline_wins{0};
    unsigned draws{0};
    std::uint64_t nodes{0};
    double elapsed_ms{0.0};
    std::vector<MatchGameResult> game_results{};

    [[nodiscard]] MatchStatistics statistics(double z = 1.96) const noexcept;
    [[nodiscard]] double candidate_score() const noexcept;
    [[nodiscard]] double candidate_score_percent() const noexcept;
};

struct ParameterChange {
    std::string name{};
    int value{0};
};

struct ExperimentCandidate {
    std::string label{};
    std::vector<ParameterChange> changes{};
};

struct ExperimentResult {
    std::string label{};
    std::vector<ParameterChange> changes{};
    MatchSummary summary{};
    MatchStatistics statistics{};
};

[[nodiscard]] bool apply_parameter_change(EvaluationParams& params,
                                           const ParameterChange& change,
                                           std::string* error = nullptr);

[[nodiscard]] std::vector<ExperimentResult> run_tuning_experiments(
    const EvaluationParams& baseline,
    const std::vector<ExperimentCandidate>& candidates,
    const TuningConfig& config,
    std::string* error = nullptr);

[[nodiscard]] MatchSummary run_tuning_match(const EvaluationParams& baseline,
                                             const EvaluationParams& candidate,
                                             const TuningConfig& config);

} // namespace ae::chess
