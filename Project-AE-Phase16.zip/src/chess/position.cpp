#include "chess/position.hpp"
#include "chess/bitboard.hpp"
#include "chess/zobrist.hpp"

namespace ae::chess {

Position::Position() { clear(); }

void Position::clear() noexcept {
    for (auto& by_color : pieces_) for (auto& bb : by_color) bb = 0;
    side_to_move_ = Color::White;
    castling_rights_ = NoCastling;
    en_passant_square_ = Square::None;
    halfmove_clock_ = 0;
    fullmove_number_ = 1;
    key_ = 0;
}

void Position::put_piece(Color c, PieceType p, Square s) noexcept {
    if (p == PieceType::None || s == Square::None) return;
    pieces_[color_index(c)][piece_index(p)] |= bit(s);
}

void Position::remove_piece(Color c, PieceType p, Square s) noexcept {
    if (p == PieceType::None || s == Square::None) return;
    pieces_[color_index(c)][piece_index(p)] &= ~bit(s);
}

std::optional<Piece> Position::piece_at(Square s) const noexcept {
    if (s == Square::None) return std::nullopt;
    const Bitboard mask = bit(s);
    for (int c = 0; c < 2; ++c)
        for (int p = 0; p < PIECE_TYPE_COUNT; ++p)
            if (pieces_[c][p] & mask)
                return Piece{static_cast<Color>(c), static_cast<PieceType>(p)};
    return std::nullopt;
}

Bitboard Position::pieces(Color c, PieceType p) const noexcept {
    return p == PieceType::None ? 0ULL : pieces_[color_index(c)][piece_index(p)];
}

Bitboard Position::occupancy(Color c) const noexcept {
    Bitboard out = 0;
    for (int p = 0; p < PIECE_TYPE_COUNT; ++p) out |= pieces_[color_index(c)][p];
    return out;
}

Bitboard Position::occupied() const noexcept {
    return occupancy(Color::White) | occupancy(Color::Black);
}

HashKey Position::compute_key() const noexcept {
    HashKey key = 0;
    for (int c = 0; c < 2; ++c) {
        for (int p = 0; p < PIECE_TYPE_COUNT; ++p) {
            Bitboard bb = pieces_[c][p];
            while (bb) {
                const int sq = static_cast<int>(lsb(bb));
                bb &= bb - 1;
                key ^= zobrist::piece[c][p][sq];
            }
        }
    }
    if (side_to_move_ == Color::Black) key ^= zobrist::side;
    key ^= zobrist::castling[static_cast<std::uint8_t>(castling_rights_) & 0x0F];
    if (en_passant_square_ != Square::None)
        key ^= zobrist::en_passant_file[file_of(en_passant_square_)];
    return key;
}

bool Position::is_consistent(std::string* reason) const noexcept {
    Bitboard seen = 0;
    for (int c = 0; c < 2; ++c) {
        for (int p = 0; p < PIECE_TYPE_COUNT; ++p) {
            const Bitboard bb = pieces_[c][p];
            if (seen & bb) {
                if (reason) *reason = "piece bitboards overlap";
                return false;
            }
            seen |= bb;
        }
    }
    if (occupancy(Color::White) & occupancy(Color::Black)) {
        if (reason) *reason = "white and black occupancies overlap";
        return false;
    }
    if (halfmove_clock_ < 0 || fullmove_number_ < 1) {
        if (reason) *reason = "invalid move counters";
        return false;
    }
    return true;
}

} // namespace ae::chess
