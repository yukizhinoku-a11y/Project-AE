#pragma once

#include "chess/evaluation.hpp"
#include "chess/tuning.hpp"
#include <cstdint>
#include <string>
#include <vector>

namespace ae::chess {

struct SearchParameter {
    std::string name{};
    int step{1};
};

enum class OptimizationDecision {
    Improved,
    Rejected,
    Inconclusive
};

struct OptimizationCandidateResult {
    std::string parameter{};
    int value{0};
    OptimizationDecision decision{OptimizationDecision::Inconclusive};
    MatchSummary summary{};
    MatchStatistics statistics{};
};

struct OptimizationStep {
    std::string parameter{};
    int starting_value{0};
    int selected_value{0};
    std::vector<OptimizationCandidateResult> candidates{};
};

struct OptimizationResult {
    EvaluationParams best_params{};
    std::vector<OptimizationStep> steps{};
    unsigned accepted_changes{0};
};

[[nodiscard]] int parameter_value(const EvaluationParams& params,
                                   const std::string& name,
                                   bool* found = nullptr) noexcept;

[[nodiscard]] bool optimize_parameters(
    EvaluationParams& best_params,
    const std::vector<SearchParameter>& parameters,
    const TuningConfig& config,
    OptimizationResult& result,
    std::string* error = nullptr);

[[nodiscard]] const char* optimization_decision_name(OptimizationDecision decision) noexcept;

} // namespace ae::chess
