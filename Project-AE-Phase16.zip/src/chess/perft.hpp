#pragma once

#include "chess/position.hpp"
#include <cstdint>

namespace ae::chess {

[[nodiscard]] std::uint64_t perft(const Position& pos, int depth) noexcept;

} // namespace ae::chess
