#pragma once

#include "chess/position.hpp"
#include <array>
#include <string>
#include <string_view>

namespace ae::chess {

// Parameter set for the classical evaluator. The default values reproduce
// the Phase 5/6/7/8 evaluator exactly. Keeping every tunable term in one
// structure makes later automated tuning reproducible and isolated from the
// evaluator implementation.
struct EvaluationParams {
    int pawn_value{100};
    int knight_value{320};
    int bishop_value{330};
    int rook_value{500};
    int queen_value{900};
    int king_value{0};

    int doubled_pawn_penalty{24};
    int isolated_pawn_penalty{10};
    int passed_pawn_base{12};
    int passed_pawn_advance{4};

    int knight_mobility{4};
    int bishop_mobility{3};
    int rook_mobility{2};
    int queen_mobility{1};

    int pawn_shield_bonus{8};
    int pawn_shield_missing_penalty{5};
    int central_king_penalty{8};
    int bishop_pair_bonus{18};

    std::array<int, 64> pawn_table{};
    std::array<int, 64> knight_table{};
    std::array<int, 64> bishop_table{};
    std::array<int, 64> rook_table{};
    std::array<int, 64> queen_table{};
    std::array<int, 64> king_table{};

    [[nodiscard]] static EvaluationParams default_v1() noexcept;
    [[nodiscard]] bool is_valid() const noexcept;
    [[nodiscard]] std::string to_text() const;
    [[nodiscard]] static bool from_text(std::string_view text, EvaluationParams& out,
                                        std::string* error = nullptr);
};

[[nodiscard]] int evaluate_material(const Position& pos) noexcept;
[[nodiscard]] int evaluate_material(const Position& pos, const EvaluationParams& params) noexcept;
[[nodiscard]] int evaluate(const Position& pos) noexcept;
[[nodiscard]] int evaluate(const Position& pos, const EvaluationParams& params) noexcept;

} // namespace ae::chess
