#pragma once

#include "chess/move.hpp"
#include "chess/position.hpp"
#include "chess/movegen.hpp"
#include "chess/evaluation.hpp"
#include <array>
#include <cstdint>
#include <vector>
#include <utility>

namespace ae::chess {

struct SearchOptions {
    bool use_pvs{true};
    bool use_lmr{true};
    bool use_null_move{true};
    bool use_aspiration{true};
};

struct SearchLimits {
    int depth{6};
    std::uint64_t node_limit{0}; // 0 = unlimited
    unsigned threads{1}; // root-level parallelism; 1 = single-threaded
    SearchOptions options{};
};

struct SearchMetrics {
    std::uint64_t nodes{0};
    std::uint64_t quiescence_nodes{0};
    std::uint64_t eval_calls{0};
    std::uint64_t tt_probes{0};
    std::uint64_t tt_hits{0};
    std::uint64_t tt_cutoffs{0};
    std::uint64_t beta_cutoffs{0};
    std::uint64_t generated_moves{0};
    std::uint64_t ordered_nodes{0};
    std::uint64_t null_move_searches{0};
    std::uint64_t null_move_cutoffs{0};
    std::uint64_t lmr_reductions{0};
    std::uint64_t pvs_searches{0};
    std::uint64_t aspiration_failures{0};
};

struct SearchResult {
    Move best_move{};
    int score{0};
    int depth{0};
    std::uint64_t nodes{0};
    std::vector<Move> principal_variation{};
    SearchMetrics metrics{};
    double elapsed_ms{0.0};
    double nodes_per_second{0.0};
    unsigned threads{1};
};

class Searcher {
public:
    explicit Searcher(EvaluationParams params = EvaluationParams::default_v1());

    void set_evaluation_params(EvaluationParams params) noexcept { eval_params_ = std::move(params); }
    [[nodiscard]] const EvaluationParams& evaluation_params() const noexcept { return eval_params_; }

    [[nodiscard]] SearchResult search(const Position& position, SearchLimits limits = {});

private:
    static constexpr int Infinity = 32000;
    static constexpr int MateScore = 30000;
    static constexpr int MaxPly = 128;
    static constexpr std::size_t TTBits = 18;
    static constexpr std::size_t TTSize = std::size_t{1} << TTBits;

    enum class TTBound : std::uint8_t { None, Exact, Lower, Upper };

    struct TTEntry {
        HashKey key{0};
        Move best_move{};
        int score{0};
        std::int16_t depth{-1};
        TTBound bound{TTBound::None};
    };

    SearchLimits limits_{};
    std::uint64_t nodes_{0};
    bool stopped_{false};
    std::vector<Move> pv_{};
    std::vector<TTEntry> tt_{};
    std::array<std::array<Move, 2>, MaxPly> killers_{};
    std::array<std::array<std::array<int, 64>, 64>, 2> history_{};
    SearchMetrics metrics_{};
    EvaluationParams eval_params_{};

    [[nodiscard]] SearchResult search_fixed_depth(const Position& position, int depth);

    [[nodiscard]] int negamax(Position& position, int depth, int alpha, int beta, int ply,
                              std::vector<Move>& pv);
    [[nodiscard]] int quiescence(Position& position, int alpha, int beta, int ply);
    [[nodiscard]] bool should_stop() noexcept;
    [[nodiscard]] bool in_check(const Position& position, Color side) const noexcept;
    [[nodiscard]] static int terminal_score(bool check, int ply) noexcept;

    [[nodiscard]] TTEntry& tt_entry(HashKey key) noexcept;
    [[nodiscard]] static int score_to_tt(int score, int ply) noexcept;
    [[nodiscard]] static int score_from_tt(int score, int ply) noexcept;
    void store_tt(HashKey key, Move best_move, int depth, int score, TTBound bound, int ply) noexcept;
    [[nodiscard]] int move_order_score(const Position& position, Move move, Move tt_move, int ply) const noexcept;
    void order_moves(const Position& position, MoveList& moves, Move tt_move, int ply) const noexcept;
    void record_killer(Move move, int ply) noexcept;
    void record_history(Color side, Move move, int depth) noexcept;
    [[nodiscard]] int evaluate_position(const Position& position) noexcept;
};

} // namespace ae::chess
