#pragma once

#include <cstdint>
#include <string_view>

namespace ae::chess {

using Bitboard = std::uint64_t;
using HashKey = std::uint64_t;

enum class Color : std::uint8_t { White = 0, Black = 1 };
constexpr int color_index(Color c) noexcept { return static_cast<int>(c); }
constexpr Color opposite(Color c) noexcept { return c == Color::White ? Color::Black : Color::White; }

enum class PieceType : std::uint8_t {
    Pawn = 0, Knight, Bishop, Rook, Queen, King, None
};
constexpr int piece_index(PieceType p) noexcept { return static_cast<int>(p); }
constexpr int PIECE_TYPE_COUNT = 6;

enum class Square : std::uint8_t {
    A1=0, B1, C1, D1, E1, F1, G1, H1,
    A2, B2, C2, D2, E2, F2, G2, H2,
    A3, B3, C3, D3, E3, F3, G3, H3,
    A4, B4, C4, D4, E4, F4, G4, H4,
    A5, B5, C5, D5, E5, F5, G5, H5,
    A6, B6, C6, D6, E6, F6, G6, H6,
    A7, B7, C7, D7, E7, F7, G7, H7,
    A8, B8, C8, D8, E8, F8, G8, H8,
    None = 64
};

constexpr int square_index(Square s) noexcept { return static_cast<int>(s); }
constexpr int file_of(Square s) noexcept { return square_index(s) & 7; }
constexpr int rank_of(Square s) noexcept { return square_index(s) >> 3; }
constexpr Bitboard bit(Square s) noexcept {
    return s == Square::None ? 0ULL : (1ULL << square_index(s));
}

enum CastlingRights : std::uint8_t {
    NoCastling = 0,
    WhiteKingSide = 1 << 0,
    WhiteQueenSide = 1 << 1,
    BlackKingSide = 1 << 2,
    BlackQueenSide = 1 << 3,
    AllCastling = WhiteKingSide | WhiteQueenSide | BlackKingSide | BlackQueenSide
};

constexpr CastlingRights operator|(CastlingRights a, CastlingRights b) noexcept {
    return static_cast<CastlingRights>(static_cast<std::uint8_t>(a) | static_cast<std::uint8_t>(b));
}
constexpr CastlingRights operator&(CastlingRights a, CastlingRights b) noexcept {
    return static_cast<CastlingRights>(static_cast<std::uint8_t>(a) & static_cast<std::uint8_t>(b));
}
constexpr CastlingRights& operator|=(CastlingRights& a, CastlingRights b) noexcept {
    a = a | b; return a;
}

struct Piece {
    Color color{};
    PieceType type{PieceType::None};
    constexpr explicit operator bool() const noexcept { return type != PieceType::None; }
};

constexpr std::string_view square_name(Square s) noexcept {
    constexpr std::string_view names[] = {
        "a1","b1","c1","d1","e1","f1","g1","h1",
        "a2","b2","c2","d2","e2","f2","g2","h2",
        "a3","b3","c3","d3","e3","f3","g3","h3",
        "a4","b4","c4","d4","e4","f4","g4","h4",
        "a5","b5","c5","d5","e5","f5","g5","h5",
        "a6","b6","c6","d6","e6","f6","g6","h6",
        "a7","b7","c7","d7","e7","f7","g7","h7",
        "a8","b8","c8","d8","e8","f8","g8","h8"
    };
    return s == Square::None ? "-" : names[square_index(s)];
}

} // namespace ae::chess
