#include "chess/zobrist.hpp"

namespace ae::chess::zobrist {

std::array<std::array<std::array<HashKey,64>, PIECE_TYPE_COUNT>, 2> piece{};
std::array<HashKey, 16> castling{};
std::array<HashKey, 8> en_passant_file{};
HashKey side{};

namespace {
std::uint64_t splitmix64(std::uint64_t& state) noexcept {
    std::uint64_t z = (state += 0x9E3779B97F4A7C15ULL);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
    return z ^ (z >> 31);
}
}

void init() noexcept {
    std::uint64_t seed = 0xAE20260923ULL;
    for (auto& by_color : piece)
        for (auto& by_piece : by_color)
            for (auto& key : by_piece)
                key = splitmix64(seed);
    for (auto& key : castling) key = splitmix64(seed);
    for (auto& key : en_passant_file) key = splitmix64(seed);
    side = splitmix64(seed);
}

} // namespace ae::chess::zobrist
