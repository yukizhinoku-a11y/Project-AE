#include "chess/selfplay.hpp"
#include "chess/fen.hpp"
#include "chess/zobrist.hpp"
#include <algorithm>
#include <chrono>
#include <random>
#include <sstream>
#include <vector>

namespace ae::chess {
namespace {

constexpr std::string_view StartFen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

Move choose_move(const Position& position, const SearchResult& result,
                 std::mt19937_64& rng, bool randomize_equal_moves) {
    if (!randomize_equal_moves || result.best_move != Move{}) return result.best_move;
    const MoveList moves = generate_legal(position);
    if (moves.size() == 0) return Move{};
    std::uniform_int_distribution<std::size_t> dist(0, moves.size() - 1);
    return moves[dist(rng)];
}

} // namespace

SelfPlayGame play_self_game(const SelfPlayConfig& config, std::uint64_t game_seed) {
    zobrist::init();
    Position start;
    std::string error;
    if (!set_from_fen(start, StartFen, &error)) {
        return {Game(start), GameResult::Draw, 0, 0.0, 0};
    }

    SelfPlayGame output;
    output.game.reset(start);
    Searcher searcher(config.evaluation_params);
    std::mt19937_64 rng(game_seed);
    const auto begin = std::chrono::steady_clock::now();

    for (int ply = 0; ply < config.max_plies; ++ply) {
        const GameResult current = output.game.result();
        if (current != GameResult::Ongoing) {
            output.result = current;
            output.plies = static_cast<int>(output.game.ply());
            break;
        }

        SearchLimits limits;
        limits.depth = config.depth;
        limits.node_limit = config.node_limit;
        limits.threads = config.threads;
        const SearchResult result = searcher.search(output.game.position(), limits);
        output.nodes += result.nodes;

        Move move = choose_move(output.game.position(), result, rng, config.randomize_equal_moves);
        if (move == Move{}) {
            output.result = output.game.result();
            output.plies = static_cast<int>(output.game.ply());
            break;
        }
        if (!output.game.play(move)) {
            output.result = GameResult::Draw;
            output.plies = static_cast<int>(output.game.ply());
            break;
        }
        output.plies = static_cast<int>(output.game.ply());
    }

    output.result = output.game.result();
    if (output.result == GameResult::Ongoing && output.plies >= config.max_plies) {
        output.result = GameResult::Draw;
    }
    const auto end = std::chrono::steady_clock::now();
    output.elapsed_ms = std::chrono::duration<double, std::milli>(end - begin).count();
    return output;
}

std::string game_result_pgn(GameResult result) {
    switch (result) {
    case GameResult::WhiteWin: return "1-0";
    case GameResult::BlackWin: return "0-1";
    case GameResult::Draw: return "1/2-1/2";
    case GameResult::Ongoing: return "*";
    }
    return "*";
}

std::string game_to_pgn(const SelfPlayGame& game, int game_number) {
    std::ostringstream out;
    out << "[Event \"Project-AE Self-Play\"]\n";
    out << "[Site \"local\"]\n";
    out << "[Round \"" << game_number << "\"]\n";
    out << "[White \"Project-AE\"]\n";
    out << "[Black \"Project-AE\"]\n";
    out << "[Result \"" << game_result_pgn(game.result) << "\"]\n\n";

    Position position;
    std::string error;
    if (!set_from_fen(position, StartFen, &error)) return out.str();

    const auto& moves = game.game.moves();
    for (std::size_t i = 0; i < moves.size(); ++i) {
        if (i % 2 == 0) out << (i / 2 + 1) << ". ";
        out << move_to_san(position, moves[i]);
        if (i % 2 == 0) out << ' ';
        else out << ' ';
        UndoState undo;
        if (!make_move(position, moves[i], undo)) return out.str();
    }
    out << game_result_pgn(game.result) << '\n';
    return out.str();
}

} // namespace ae::chess
