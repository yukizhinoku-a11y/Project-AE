#pragma once

#include "chess/game.hpp"
#include "chess/search.hpp"
#include <cstdint>
#include <string>

namespace ae::chess {

struct SelfPlayConfig {
    int depth{3};
    std::uint64_t node_limit{0};
    unsigned threads{1};
    int max_plies{300};
    unsigned games{1};
    std::uint64_t seed{1};
    bool randomize_equal_moves{false};
    EvaluationParams evaluation_params{EvaluationParams::default_v1()};
};

struct SelfPlayGame {
    Game game;
    GameResult result{GameResult::Ongoing};
    std::uint64_t nodes{0};
    double elapsed_ms{0.0};
    int plies{0};
};

[[nodiscard]] SelfPlayGame play_self_game(const SelfPlayConfig& config, std::uint64_t game_seed);
[[nodiscard]] std::string game_to_pgn(const SelfPlayGame& game, int game_number = 1);
[[nodiscard]] std::string game_result_pgn(GameResult result);

} // namespace ae::chess
