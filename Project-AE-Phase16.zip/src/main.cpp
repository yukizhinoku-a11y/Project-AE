#include "chess/fen.hpp"
#include "chess/search.hpp"
#include "chess/zobrist.hpp"
#include "chess/game.hpp"
#include <iostream>
#include <string>

int main() {
    using namespace ae::chess;
    zobrist::init();

    Position position;
    std::string error;
    constexpr auto start_fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
    if (!set_from_fen(position, start_fen, &error)) {
        std::cerr << "Project-AE initialization failed: " << error << '\n';
        return 1;
    }

    Searcher searcher;
    const auto result = searcher.search(position, SearchLimits{4, 0, 1});

    std::cout << "Project-AE Search Engine v1 + Evaluation v1\n"
              << "Depth: " << result.depth << '\n'
              << "Nodes: " << result.nodes << '\n'
              << "Score: " << result.score << " cp\n"
              << "Time: " << result.elapsed_ms << " ms\n"
              << "NPS: " << result.nodes_per_second << "\n"
              << "Threads: " << result.threads << "\n"
              << "TT hits: " << result.metrics.tt_hits << " / " << result.metrics.tt_probes << "\n"
              << "Beta cutoffs: " << result.metrics.beta_cutoffs << "\n"
              << "Eval calls: " << result.metrics.eval_calls << "\n"
              << "Best move: " << (result.best_move ? move_to_uci(result.best_move) : "(none)") << '\n'
              << "PV:";
    for (const Move move : result.principal_variation)
        std::cout << ' ' << move_to_uci(move);
    std::cout << '\n';
    return 0;
}
