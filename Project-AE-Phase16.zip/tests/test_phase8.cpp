#include "chess/fen.hpp"
#include "chess/search.hpp"
#include "chess/zobrist.hpp"
#include <cassert>
#include <iostream>
#include <string>

using namespace ae::chess;

int main() {
    zobrist::init();
    Position p;
    std::string error;
    assert(set_from_fen(p, "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", &error));

    Searcher single;
    Searcher parallel;
    const auto a = single.search(p, SearchLimits{3, 0, 1});
    const auto b = parallel.search(p, SearchLimits{3, 0, 2});

    assert(a.depth == 3);
    assert(b.depth == 3);
    assert(a.best_move == b.best_move);
    assert(a.score == b.score);
    assert(b.threads == 2);
    assert(b.nodes > 0);
    assert(!b.principal_variation.empty());

    std::cout << "Phase 8: PASS\n";
    return 0;
}
