#include "chess/attacks.hpp"
#include "chess/fen.hpp"
#include "chess/makemove.hpp"
#include "chess/movegen.hpp"
#include "chess/perft.hpp"
#include "chess/zobrist.hpp"
#include <iostream>
#include <string>

using namespace ae::chess;

namespace {
int failures = 0;

void check(bool condition, const char* name) {
    if (!condition) {
        ++failures;
        std::cerr << "[FAIL] " << name << '\n';
    } else {
        std::cout << "[PASS] " << name << '\n';
    }
}

Position from_fen(const char* fen) {
    Position p;
    std::string error;
    if (!set_from_fen(p, fen, &error)) {
        std::cerr << "FEN error: " << error << '\n';
        ++failures;
    }
    return p;
}

bool contains(const MoveList& moves, Square from, Square to, MoveFlag flag) {
    for (const Move m : moves)
        if (m.from() == from && m.to() == to && m.flag() == flag) return true;
    return false;
}
}

int main() {
    zobrist::init();

    const Position start = from_fen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
    const MoveList start_moves = generate_legal(start);
    check(start_moves.size() == 20, "starting position has 20 legal moves");
    check(contains(start_moves, Square::E2, Square::E4, MoveFlag::DoublePawnPush), "e2-e4 generated");
    check(contains(start_moves, Square::G1, Square::F3, MoveFlag::Quiet), "g1-f3 generated");

    check(perft(start, 1) == 20, "start perft depth 1");
    check(perft(start, 2) == 400, "start perft depth 2");
    check(perft(start, 3) == 8902, "start perft depth 3");
    check(perft(start, 4) == 197281, "start perft depth 4");

    const Position kiwipete = from_fen("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1");
    check(perft(kiwipete, 1) == 48, "Kiwipete perft depth 1");
    check(perft(kiwipete, 2) == 2039, "Kiwipete perft depth 2");
    check(perft(kiwipete, 3) == 97862, "Kiwipete perft depth 3");
    check(perft(kiwipete, 4) == 4085603, "Kiwipete perft depth 4");

    const Position ep = from_fen("8/8/8/3pP3/8/8/8/4K2k w - d6 0 2");
    const MoveList ep_moves = generate_legal(ep);
    check(contains(ep_moves, Square::E5, Square::D6, MoveFlag::EnPassant), "en-passant capture generated");

    const Position castle = from_fen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1");
    const MoveList castle_moves = generate_legal(castle);
    check(contains(castle_moves, Square::E1, Square::G1, MoveFlag::KingCastle), "white kingside castling generated");
    check(contains(castle_moves, Square::E1, Square::C1, MoveFlag::QueenCastle), "white queenside castling generated");

    const Position promotion = from_fen("4k3/P7/8/8/8/8/8/4K3 w - - 0 1");
    const MoveList promotion_moves = generate_legal(promotion);
    int promotion_count = 0;
    for (const Move m : promotion_moves) if (m.from() == Square::A7 && m.to() == Square::A8) ++promotion_count;
    check(promotion_count == 4, "quiet promotion generates four choices");
    check(contains(promotion_moves, Square::A7, Square::A8, MoveFlag::PromotionQueen), "queen promotion generated");

    Position after = start;
    const HashKey start_key = after.key();
    check(make_move(after, Move(Square::E2, Square::E4, MoveFlag::DoublePawnPush)), "make e2-e4");
    check(after.side_to_move() == Color::Black, "side switches after move");
    check(after.en_passant_square() == Square::E3, "double pawn push sets e3 en-passant square");
    check(after.piece_at(Square::E4).has_value(), "pawn appears on e4");
    check(after.key() == after.compute_key(), "post-move Zobrist key is correct");
    check(after.key() != start_key, "position key changes after move");

    {
        Position roundtrip = start;
        const HashKey original_key = roundtrip.key();
        const MoveList moves = generate_legal(roundtrip);
        bool all_roundtrip = true;
        for (const Move m : moves) {
            UndoState undo;
            if (!make_move(roundtrip, m, undo)) { all_roundtrip = false; break; }
            unmake_move(roundtrip, m, undo);
            if (roundtrip.key() != original_key || !roundtrip.is_consistent()) { all_roundtrip = false; break; }
        }
        check(all_roundtrip, "make/unmake round-trip preserves every start position move");
    }

    const Position perft3 = from_fen("8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1");
    check(perft(perft3, 1) == 14, "perft position 3 depth 1");
    check(perft(perft3, 2) == 191, "perft position 3 depth 2");
    check(perft(perft3, 3) == 2812, "perft position 3 depth 3");

    const Position pinned = from_fen("4r1k1/8/8/8/8/8/4R3/4K3 w - - 0 1");
    const MoveList pinned_moves = generate_legal(pinned);
    check(!contains(pinned_moves, Square::E2, Square::A2, MoveFlag::Quiet), "illegal pinned rook move rejected");

    if (failures == 0) std::cout << "All Phase 2 tests passed.\n";
    return failures == 0 ? 0 : 1;
}
