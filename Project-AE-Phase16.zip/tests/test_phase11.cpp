#include "chess/selfplay.hpp"
#include "chess/fen.hpp"
#include "chess/zobrist.hpp"
#include <fstream>
#include <iostream>
#include <string>

using namespace ae::chess;

int main() {
    zobrist::init();
    SelfPlayConfig config;
    config.depth = 1;
    config.max_plies = 4;
    config.games = 1;
    config.threads = 1;
    config.seed = 42;

    const SelfPlayGame game = play_self_game(config, config.seed);
    if (game.plies != 4 || game.game.moves().size() != 4) {
        std::cerr << "Phase 11 failure: expected exactly 4 plies, got " << game.plies << "\n";
        return 1;
    }
    if (game.result != GameResult::Draw) {
        std::cerr << "Phase 11 failure: max-ply game should be a draw, got "
                  << game_result_pgn(game.result) << "\n";
        return 1;
    }
    if (game.nodes == 0) {
        std::cerr << "Phase 11 failure: self-play produced zero search nodes\n";
        return 1;
    }
    if (game.elapsed_ms < 0.0) {
        std::cerr << "Phase 11 failure: negative elapsed time\n";
        return 1;
    }

    const std::string pgn = game_to_pgn(game, 1);
    if (pgn.find("[Event \"Project-AE Self-Play\"]") == std::string::npos ||
        pgn.find("[Result \"1/2-1/2\"]") == std::string::npos ||
        pgn.find("1. ") == std::string::npos ||
        pgn.find("2. ") == std::string::npos) {
        std::cerr << "Phase 11 failure: PGN structure invalid\n";
        return 1;
    }

    Position start;
    std::string error;
    if (!set_from_fen(start,
        "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", &error)) {
        std::cerr << "Phase 11 failure: start FEN: " << error << "\n";
        return 1;
    }
    if (to_fen(game.game.position()) == to_fen(start)) {
        std::cerr << "Phase 11 failure: game position did not advance\n";
        return 1;
    }

    std::cout << "Phase 11: PASS\n";
    std::cout << "Plies: " << game.plies << "\n";
    std::cout << "Nodes: " << game.nodes << "\n";
    return 0;
}
