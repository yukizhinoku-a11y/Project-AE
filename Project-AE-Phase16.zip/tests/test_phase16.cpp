#include "chess/fen.hpp"
#include "chess/search.hpp"
#include "chess/zobrist.hpp"
#include <iostream>
#include <string>

using namespace ae::chess;

static bool load(Position& p, const char* fen, std::string& error) {
    if (!set_from_fen(p, fen, &error)) return false;
    return p.is_consistent(&error);
}

int main() {
    zobrist::init();
    const char* start = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
    const char* tactical = "6k1/5ppp/8/8/8/8/5PPP/6KQ w - - 0 1";
    std::string error;

    Position p;
    if (!load(p, start, error)) {
        std::cerr << "Phase 16 failure: start position: " << error << '\n';
        return 1;
    }
    const HashKey start_key = p.key();

    SearchOptions baseline{false, false, false, false};
    SearchOptions pvs_only{true, false, false, false};
    SearchOptions lmr_only{false, true, false, false};
    SearchOptions null_only{false, false, true, false};
    SearchOptions asp_only{false, false, false, true};
    SearchOptions all{true, true, true, true};

    for (const auto& options : {baseline, pvs_only, lmr_only, null_only, asp_only, all}) {
        Searcher searcher;
        const SearchResult r = searcher.search(p, SearchLimits{4, 50000, 1, options});
        if (r.depth < 1 || !r.best_move || r.nodes == 0) {
            std::cerr << "Phase 16 failure: incomplete search\n";
            return 1;
        }
        if (p.key() != start_key || !p.is_consistent(&error)) {
            std::cerr << "Phase 16 failure: search modified position: " << error << '\n';
            return 1;
        }
    }

    Searcher advanced;
    const SearchResult r = advanced.search(p, SearchLimits{4, 50000, 1, all});
    if (r.metrics.pvs_searches == 0 || r.metrics.lmr_reductions == 0) {
        std::cerr << "Phase 16 failure: advanced search instrumentation not exercised\n";
        return 1;
    }

    Position t;
    if (!load(t, tactical, error)) {
        std::cerr << "Phase 16 failure: tactical position: " << error << '\n';
        return 1;
    }
    const HashKey tactical_key = t.key();
    const SearchResult tr = advanced.search(t, SearchLimits{5, 50000, 1, all});
    if (tr.metrics.null_move_searches == 0) {
        std::cerr << "Phase 16 failure: null-move instrumentation not exercised\n";
        return 1;
    }
    if (t.key() != tactical_key || !t.is_consistent(&error)) {
        std::cerr << "Phase 16 failure: tactical search modified position: " << error << '\n';
        return 1;
    }

    // The Phase-7-style baseline must be selectable independently of Phase-15 additions.
    const SearchResult br = advanced.search(p, SearchLimits{4, 50000, 1, baseline});
    if (br.metrics.pvs_searches != 0 || br.metrics.lmr_reductions != 0 || br.metrics.null_move_searches != 0) {
        std::cerr << "Phase 16 failure: baseline mode still enabled Phase-15 features\n";
        return 1;
    }

    std::cout << "Phase 16: PASS\n";
    std::cout << "Baseline nodes: " << br.nodes << "\n";
    std::cout << "V2 nodes: " << r.nodes << "\n";
    std::cout << "V2 PVS: " << r.metrics.pvs_searches << "\n";
    std::cout << "V2 LMR: " << r.metrics.lmr_reductions << "\n";
    std::cout << "V2 null searches: " << r.metrics.null_move_searches << "\n";
    std::cout << "V2 aspiration failures: " << r.metrics.aspiration_failures << "\n";
    return 0;
}
