#include "chess/evaluation.hpp"
#include "chess/fen.hpp"
#include "chess/search.hpp"
#include "chess/zobrist.hpp"
#include <iostream>
#include <string>

using namespace ae::chess;
namespace {
int failures = 0;
void check(bool c, const char* n) { if (!c) { ++failures; std::cerr << "[FAIL] " << n << '\n'; } else std::cout << "[PASS] " << n << '\n'; }
Position fen(const char* s) { Position p; std::string e; if (!set_from_fen(p, s, &e)) { ++failures; std::cerr << e << '\n'; } return p; }
}

int main() {
    zobrist::init();

    const Position start = fen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
    check(evaluate_material(start) == 0, "starting material is equal");

    const Position queen_up = fen("7k/8/8/8/8/8/6Q1/K7 w - - 0 1");
    check(evaluate_material(queen_up) == 900, "material evaluation detects queen advantage");

    Searcher searcher;
    const auto mate = searcher.search(fen("7k/5Q2/6K1/8/8/8/8/8 w - - 0 1"), SearchLimits{2, 0});
    check(mate.best_move == Move(Square::F7, Square::G7), "search finds mate in one");
    check(mate.score >= 29900, "mate score is reported");
    check(mate.depth == 2, "iterative deepening reaches requested depth");
    check(mate.nodes > 0, "search counts nodes");

    const auto capture = searcher.search(fen("6k1/8/8/8/8/8/3q4/3Q2K1 w - - 0 1"), SearchLimits{2, 0});
    check(capture.best_move == Move(Square::D1, Square::D2, MoveFlag::Capture), "search finds winning queen capture");

    const auto limited = searcher.search(start, SearchLimits{8, 1000});
    check(limited.nodes <= 1000, "node limit is respected");
    check(static_cast<bool>(limited.best_move), "node-limited search still returns a move");

    if (failures == 0) std::cout << "All Phase 4 tests passed.\n";
    return failures == 0 ? 0 : 1;
}
