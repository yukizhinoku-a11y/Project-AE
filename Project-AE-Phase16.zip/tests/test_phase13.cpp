#include "chess/tuning.hpp"
#include "chess/zobrist.hpp"
#include <cmath>
#include <iostream>

using namespace ae::chess;

int main() {
    zobrist::init();
    const EvaluationParams baseline = EvaluationParams::default_v1();

    TuningConfig config;
    config.games = 4;
    config.depth = 1;
    config.max_plies = 4;
    config.seed = 42;

    const std::vector<ExperimentCandidate> candidates = {
        {"pawn_value=95", {{"pawn_value", 95}}},
        {"pawn_value=105", {{"pawn_value", 105}}}
    };
    std::string error;
    const auto results = run_tuning_experiments(baseline, candidates, config, &error);
    if (results.size() != 2) {
        std::cerr << "Phase 13 failure: expected two experiment results: " << error << "\n";
        return 1;
    }
    for (const auto& result : results) {
        if (result.summary.games != 4 || result.summary.game_results.size() != 4) {
            std::cerr << "Phase 13 failure: game batch size mismatch\n";
            return 1;
        }
        if (result.summary.candidate_wins + result.summary.baseline_wins + result.summary.draws != 4) {
            std::cerr << "Phase 13 failure: result accounting mismatch\n";
            return 1;
        }
        const auto& st = result.statistics;
        if (st.confidence_low < 0.0 || st.confidence_high > 1.0 || st.confidence_low > st.confidence_high) {
            std::cerr << "Phase 13 failure: invalid confidence interval\n";
            return 1;
        }
        if (st.is_inconclusive() != !(st.statistically_above_baseline || st.statistically_below_baseline)) {
            std::cerr << "Phase 13 failure: status flags inconsistent\n";
            return 1;
        }
    }

    const auto& a = results[0].summary.game_results;
    const auto& b = results[1].summary.game_results;
    if (a.size() != b.size()) {
        std::cerr << "Phase 13 failure: deterministic batch size mismatch\n";
        return 1;
    }
    for (std::size_t i = 0; i < a.size(); ++i) {
        if (a[i].candidate_white != (i % 2 == 0) || b[i].candidate_white != (i % 2 == 0)) {
            std::cerr << "Phase 13 failure: color balancing mismatch\n";
            return 1;
        }
    }

    // Synthetic accounting sanity check for a clearly non-neutral result.
    MatchSummary synthetic;
    synthetic.games = 10;
    synthetic.candidate_wins = 10;
    for (int i = 0; i < 10; ++i) synthetic.game_results.push_back({GameResult::WhiteWin, true, 0, 0.0, 1, {}});
    const auto st = synthetic.statistics();
    if (!st.statistically_above_baseline || st.confidence_low <= 0.5) {
        std::cerr << "Phase 13 failure: strong synthetic result was not detected\n";
        return 1;
    }

    std::cout << "Phase 13: PASS\n";
    std::cout << "Experiments: " << results.size() << "\n";
    std::cout << "Games per experiment: " << config.games << "\n";
    return 0;
}
