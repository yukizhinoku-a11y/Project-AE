#include "chess/bitboard.hpp"
#include "chess/fen.hpp"
#include "chess/zobrist.hpp"
#include <iostream>
#include <string>

using namespace ae::chess;

namespace {
int failures = 0;

void check(bool condition, const char* name) {
    if (!condition) {
        ++failures;
        std::cerr << "[FAIL] " << name << '\n';
    } else {
        std::cout << "[PASS] " << name << '\n';
    }
}
}

int main() {
    zobrist::init();

    check(square_index(Square::A1) == 0, "a1 index is 0");
    check(square_index(Square::H8) == 63, "h8 index is 63");
    check(file_of(Square::E4) == 4 && rank_of(Square::E4) == 3, "square file/rank mapping");
    check(bit(Square::A1) == 1ULL, "a1 bit mask");
    check(bit(Square::H8) == (1ULL << 63), "h8 bit mask");

    Position start;
    std::string error;
    constexpr auto start_fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
    check(set_from_fen(start, start_fen, &error), "parse starting FEN");
    check(popcount(start.occupancy(Color::White)) == 16, "white has 16 pieces");
    check(popcount(start.occupancy(Color::Black)) == 16, "black has 16 pieces");
    check(popcount(start.occupied()) == 32, "starting position has 32 pieces");
    check(popcount(start.pieces(Color::White, PieceType::Pawn)) == 8, "white has 8 pawns");
    check(popcount(start.pieces(Color::Black, PieceType::Knight)) == 2, "black has 2 knights");
    check(start.side_to_move() == Color::White, "white to move");
    check(start.castling_rights() == AllCastling, "all castling rights present");
    check(start.en_passant_square() == Square::None, "no en-passant square");
    check(start.halfmove_clock() == 0 && start.fullmove_number() == 1, "move counters parsed");
    check(start.key() == start.compute_key(), "stored Zobrist key matches recomputation");
    check(start.is_consistent(), "starting position is internally consistent");

    auto white_king = start.piece_at(Square::E1);
    check(white_king && white_king->color == Color::White && white_king->type == PieceType::King,
          "white king found on e1");

    Position ep;
    check(set_from_fen(ep, "8/8/8/3pP3/8/8/8/4K2k w - d6 0 2", &error), "parse en-passant FEN");
    check(ep.en_passant_square() == Square::D6, "en-passant square is d6");

    Position invalid;
    check(!set_from_fen(invalid, "8/8/8/8/8/8/8/8 w - - 0", &error), "reject FEN with missing field");
    check(!set_from_fen(invalid, "8/8/8/8/8/8/8/9 w - - 0 1", &error), "reject invalid board FEN");

    if (failures == 0) std::cout << "All Phase 1 tests passed.\n";
    return failures == 0 ? 0 : 1;
}
