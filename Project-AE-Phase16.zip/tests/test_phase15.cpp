#include "chess/fen.hpp"
#include "chess/search.hpp"
#include "chess/zobrist.hpp"
#include <iostream>

using namespace ae::chess;

int main() {
    zobrist::init();
    Position position;
    std::string error;
    if (!set_from_fen(position, "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", &error)) {
        std::cerr << "Phase 15 failure: FEN: " << error << "\n";
        return 1;
    }
    if (!position.is_consistent(&error)) {
        std::cerr << "Phase 15 failure: inconsistent position: " << error << "\n";
        return 1;
    }

    Searcher searcher;
    SearchLimits limits;
    limits.depth = 3;
    limits.node_limit = 100000;
    limits.threads = 1;
    const SearchResult result = searcher.search(position, limits);
    if (result.depth < 1 || result.best_move == Move{}) {
        std::cerr << "Phase 15 failure: incomplete search\n";
        return 1;
    }
    if (result.metrics.pvs_searches == 0) {
        std::cerr << "Phase 15 failure: PVS was not exercised\n";
        return 1;
    }
    if (result.metrics.lmr_reductions == 0) {
        std::cerr << "Phase 15 failure: LMR was not exercised\n";
        return 1;
    }

    // A tactical position should exercise null-move pruning without changing
    // the position itself.
    Position tactical;
    if (!set_from_fen(tactical, "6k1/5ppp/8/8/8/8/5PPP/6KQ w - - 0 1", &error)) {
        std::cerr << "Phase 15 failure: tactical FEN: " << error << "\n";
        return 1;
    }
    const HashKey before = tactical.key();
    SearchLimits tactical_limits{5, 20000, 1};
    const SearchResult tactical_result = searcher.search(tactical, tactical_limits);
    if (tactical.key() != before || !tactical.is_consistent(&error)) {
        std::cerr << "Phase 15 failure: search modified position\n";
        return 1;
    }
    if (tactical_result.metrics.null_move_searches == 0) {
        std::cerr << "Phase 15 failure: null-move pruning was not exercised\n";
        return 1;
    }

    std::cout << "Phase 15: PASS\n";
    std::cout << "Depth: " << result.depth << "\n";
    std::cout << "Nodes: " << result.nodes << "\n";
    std::cout << "PVS searches: " << result.metrics.pvs_searches << "\n";
    std::cout << "LMR reductions: " << result.metrics.lmr_reductions << "\n";
    std::cout << "Null-move searches: " << tactical_result.metrics.null_move_searches << "\n";
    std::cout << "Null-move cutoffs: " << tactical_result.metrics.null_move_cutoffs << "\n";
    std::cout << "Aspiration failures: " << result.metrics.aspiration_failures << "\n";
    return 0;
}
