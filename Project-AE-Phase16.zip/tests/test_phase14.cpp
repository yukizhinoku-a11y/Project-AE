#include "chess/optimizer.hpp"
#include "chess/zobrist.hpp"
#include <iostream>

using namespace ae::chess;

int main() {
    zobrist::init();
    EvaluationParams params = EvaluationParams::default_v1();

    bool found = false;
    if (parameter_value(params, "pawn_value", &found) != 100 || !found) {
        std::cerr << "Phase 14 failure: parameter lookup failed\n";
        return 1;
    }
    (void)parameter_value(params, "does_not_exist", &found);
    if (found) {
        std::cerr << "Phase 14 failure: unknown parameter reported as found\n";
        return 1;
    }

    TuningConfig config;
    config.games = 2;
    config.depth = 1;
    config.max_plies = 4;
    config.seed = 123;

    OptimizationResult result;
    std::string error;
    const std::vector<SearchParameter> parameters = {
        {"pawn_value", 5},
        {"bishop_pair_bonus", 2}
    };
    if (!optimize_parameters(params, parameters, config, result, &error)) {
        std::cerr << "Phase 14 failure: optimizer returned error: " << error << "\n";
        return 1;
    }
    if (result.steps.size() != parameters.size()) {
        std::cerr << "Phase 14 failure: step count mismatch\n";
        return 1;
    }
    if (result.best_params.to_text().empty()) {
        std::cerr << "Phase 14 failure: final parameters empty\n";
        return 1;
    }
    for (const auto& step : result.steps) {
        if (step.candidates.size() != 2) {
            std::cerr << "Phase 14 failure: expected lower/upper candidate pair\n";
            return 1;
        }
        if (step.selected_value != step.starting_value) {
            bool valid_selected = false;
            const int value = parameter_value(result.best_params, step.parameter, &valid_selected);
            if (!valid_selected || value != step.selected_value) {
                std::cerr << "Phase 14 failure: selected value not reflected in final parameters\n";
                return 1;
            }
        }
        for (const auto& candidate : step.candidates) {
            if (candidate.summary.games != config.games || candidate.summary.game_results.size() != config.games) {
                std::cerr << "Phase 14 failure: candidate game batch mismatch\n";
                return 1;
            }
            if (candidate.summary.candidate_wins + candidate.summary.baseline_wins + candidate.summary.draws != config.games) {
                std::cerr << "Phase 14 failure: candidate result accounting mismatch\n";
                return 1;
            }
        }
    }

    EvaluationParams invalid = EvaluationParams::default_v1();
    if (optimize_parameters(invalid, {{"unknown", 1}}, config, result, &error)) {
        std::cerr << "Phase 14 failure: unknown parameter accepted\n";
        return 1;
    }

    std::cout << "Phase 14: PASS\n";
    std::cout << "Parameters searched: " << parameters.size() << "\n";
    std::cout << "Accepted changes: " << result.accepted_changes << "\n";
    return 0;
}
