#include "chess/fen.hpp"
#include "chess/game.hpp"
#include "chess/zobrist.hpp"
#include <iostream>
#include <string>

using namespace ae::chess;
namespace { int failures = 0; void check(bool c, const char* n) { if (!c) { ++failures; std::cerr << "[FAIL] " << n << '\n'; } else std::cout << "[PASS] " << n << '\n'; } Position fen(const char* s) { Position p; std::string e; if (!set_from_fen(p,s,&e)) { ++failures; std::cerr << e << '\n'; } return p; } }

int main() {
    zobrist::init();
    const Position start = fen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
    check(to_fen(start) == "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", "starting FEN round-trip");

    Game game(start);
    check(game.play_uci("e2e4"), "play e2e4");
    check(game.play_uci("e7e5"), "play e7e5");
    check(game.play_uci("g1f3"), "play g1f3");
    check(move_to_uci(game.moves()[0]) == "e2e4", "UCI move formatting");
    check(move_to_san(start, game.moves()[0]) == "e4", "SAN formatting for e4");
    check(to_fen(game.position()) == "rnbqkbnr/pppp1ppp/8/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R b KQkq - 1 2", "game FEN after three plies");
    check(game.undo(), "undo last move");
    check(game.ply() == 2, "undo reduces ply count");
    check(game.play_uci("g1f3"), "replay g1f3");

    Game repetition(fen("7k/8/8/8/8/8/6N1/K7 w - - 0 1"));
    check(repetition.play_uci("g2h4"), "repetition move 1");
    check(repetition.play_uci("h8g8"), "repetition move 2");
    check(repetition.play_uci("h4g2"), "repetition move 3");
    check(repetition.play_uci("g8h8"), "repetition move 4");
    check(repetition.play_uci("g2h4"), "repetition move 5");
    check(repetition.play_uci("h8g8"), "repetition move 6");
    check(repetition.play_uci("h4g2"), "repetition move 7");
    check(repetition.play_uci("g8h8"), "repetition move 8");
    check(repetition.is_threefold_repetition(), "threefold repetition detected");
    check(repetition.result() == GameResult::Draw, "threefold repetition is a draw");

    const Position fifty = fen("7k/8/8/8/8/8/6N1/K7 w - - 100 51");
    Game fifty_game(fifty);
    check(fifty_game.is_fifty_move_draw(), "fifty-move rule detected");

    check(Game(fen("7k/8/8/8/8/8/8/K7 w - - 0 1")).is_insufficient_material(), "king versus king insufficient material");
    check(Game(fen("7k/8/8/8/8/8/6N1/K7 w - - 0 1")).is_insufficient_material(), "king and knight versus king insufficient material");
    check(Game(fen("7k/8/8/8/8/8/6B1/K7 w - - 0 1")).is_insufficient_material(), "king and bishop versus king insufficient material");

    const Position mate = fen("7k/6Q1/5K2/8/8/8/8/8 b - - 0 1");
    Game mate_game(mate);
    check(mate_game.is_checkmate(), "checkmate detected");
    check(mate_game.result() == GameResult::WhiteWin, "checkmate result is white win");

    const Position stale = fen("7k/5Q2/6K1/8/8/8/8/8 b - - 0 1");
    Game stale_game(stale);
    check(stale_game.is_stalemate(), "stalemate detected");
    check(stale_game.result() == GameResult::Draw, "stalemate is a draw");

    if (failures == 0) std::cout << "All Phase 3 tests passed.\n";
    return failures == 0 ? 0 : 1;
}
