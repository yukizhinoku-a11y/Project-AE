#include "chess/evaluation.hpp"
#include "chess/fen.hpp"
#include "chess/search.hpp"
#include "chess/zobrist.hpp"
#include <cassert>
#include <iostream>
#include <string>

using namespace ae::chess;

int main() {
    zobrist::init();

    Position start;
    std::string error;
    assert(set_from_fen(start, "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", &error));

    const EvaluationParams defaults = EvaluationParams::default_v1();
    assert(defaults.is_valid());
    assert(evaluate(start) == evaluate(start, defaults));
    assert(evaluate_material(start) == evaluate_material(start, defaults));

    const std::string serialized = defaults.to_text();
    EvaluationParams round_trip;
    assert(EvaluationParams::from_text(serialized, round_trip, &error));
    assert(round_trip.to_text() == serialized);
    assert(evaluate(start, round_trip) == evaluate(start, defaults));

    EvaluationParams candidate = defaults;
    candidate.pawn_value += 10;
    assert(evaluate_material(start, candidate) == evaluate_material(start, defaults));

    Position pawn_position;
    assert(set_from_fen(pawn_position, "4k3/8/8/8/8/8/P7/4K3 w - - 0 1", &error));
    assert(evaluate_material(pawn_position, candidate) > evaluate_material(pawn_position, defaults));
    assert(evaluate(pawn_position, candidate) > evaluate(pawn_position, defaults));

    Searcher baseline;
    Searcher tuned(candidate);
    const auto baseline_result = baseline.search(start, SearchLimits{2, 0, 1});
    const auto tuned_result = tuned.search(start, SearchLimits{2, 0, 1});
    assert(baseline_result.depth == tuned_result.depth);
    assert(tuned.evaluation_params().pawn_value == defaults.pawn_value + 10);

    EvaluationParams invalid = defaults;
    invalid.pawn_value = -1;
    assert(!invalid.is_valid());
    EvaluationParams rejected;
    assert(!EvaluationParams::from_text("version=1\npawn_value=-1\n", rejected, &error));

    std::cout << "Phase 9: PASS\n";
    return 0;
}
