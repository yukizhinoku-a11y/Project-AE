#include "chess/tuning.hpp"
#include "chess/zobrist.hpp"
#include <iostream>

using namespace ae::chess;

int main() {
    zobrist::init();
    const EvaluationParams baseline = EvaluationParams::default_v1();
    EvaluationParams candidate = baseline;
    std::string error;

    if (!apply_parameter_change(candidate, {"pawn_value", 105}, &error)) {
        std::cerr << "Phase 12 failure: candidate parameter rejected: " << error << "\n";
        return 1;
    }
    if (candidate.pawn_value != 105 || !candidate.is_valid()) {
        std::cerr << "Phase 12 failure: candidate parameter was not applied\n";
        return 1;
    }
    if (apply_parameter_change(candidate, {"not_a_parameter", 1}, &error)) {
        std::cerr << "Phase 12 failure: unknown parameter accepted\n";
        return 1;
    }

    TuningConfig config;
    config.games = 2;
    config.depth = 1;
    config.max_plies = 4;
    config.seed = 42;

    const MatchSummary summary = run_tuning_match(baseline, candidate, config);
    if (summary.games != 2 || summary.game_results.size() != 2) {
        std::cerr << "Phase 12 failure: expected 2 recorded games\n";
        return 1;
    }
    if (summary.candidate_wins + summary.baseline_wins + summary.draws != summary.games) {
        std::cerr << "Phase 12 failure: match result accounting mismatch\n";
        return 1;
    }
    if (summary.nodes == 0 || summary.elapsed_ms < 0.0) {
        std::cerr << "Phase 12 failure: invalid match metrics\n";
        return 1;
    }
    if (summary.candidate_score_percent() < 0.0 || summary.candidate_score_percent() > 100.0) {
        std::cerr << "Phase 12 failure: invalid candidate score percentage\n";
        return 1;
    }
    if (!summary.game_results[0].candidate_white || summary.game_results[1].candidate_white) {
        std::cerr << "Phase 12 failure: candidate colors did not alternate\n";
        return 1;
    }

    std::cout << "Phase 12: PASS\n";
    std::cout << "Games: " << summary.games << "\n";
    std::cout << "Nodes: " << summary.nodes << "\n";
    return 0;
}
