#include "chess/evaluation.hpp"
#include "chess/fen.hpp"
#include <cassert>
#include <cmath>
#include <fstream>
#include <stdexcept>
#include <iostream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

using namespace ae::chess;

struct Case {
    std::string id, category, fen, rule, reference;
    int score{};
};

static std::vector<Case> load_suite(const std::string& path) {
    std::ifstream in(path);
    if (!in) { throw std::runtime_error("unable to open Phase 10 suite: " + path); }
    std::vector<Case> cases;
    std::string line;
    while (std::getline(in, line)) {
        if (line.empty() || line[0] == '#') continue;
        std::stringstream ss(line);
        std::vector<std::string> fields;
        std::string field;
        while (std::getline(ss, field, '|')) fields.push_back(field);
        if (fields.size() != 5) { throw std::runtime_error("invalid Phase 10 suite line: expected 5 fields"); }
        cases.push_back({fields[0], fields[1], fields[2], fields[3], fields[4], 0});
    }
    return cases;
}

static EvaluationParams isolated_profile(const std::string& category) {
    EvaluationParams p = EvaluationParams::default_v1();
    if (category == "material") {
        p.pawn_table.fill(0); p.knight_table.fill(0); p.bishop_table.fill(0);
        p.rook_table.fill(0); p.queen_table.fill(0); p.king_table.fill(0);
        p.doubled_pawn_penalty = p.isolated_pawn_penalty = 0;
        p.passed_pawn_base = p.passed_pawn_advance = 0;
        p.knight_mobility = p.bishop_mobility = p.rook_mobility = p.queen_mobility = 0;
        p.pawn_shield_bonus = p.pawn_shield_missing_penalty = p.central_king_penalty = p.bishop_pair_bonus = 0;
    } else if (category == "pawn_structure") {
        p.pawn_value = p.knight_value = p.bishop_value = p.rook_value = p.queen_value = 0;
        p.pawn_table.fill(0); p.knight_table.fill(0); p.bishop_table.fill(0);
        p.rook_table.fill(0); p.queen_table.fill(0); p.king_table.fill(0);
        p.knight_mobility = p.bishop_mobility = p.rook_mobility = p.queen_mobility = 0;
        p.pawn_shield_bonus = p.pawn_shield_missing_penalty = p.central_king_penalty = p.bishop_pair_bonus = 0;
    } else if (category == "piece_activity") {
        p.pawn_value = p.knight_value = p.bishop_value = p.rook_value = p.queen_value = 0;
        p.pawn_table.fill(0); p.knight_table.fill(0); p.bishop_table.fill(0);
        p.rook_table.fill(0); p.queen_table.fill(0); p.king_table.fill(0);
        p.doubled_pawn_penalty = p.isolated_pawn_penalty = 0;
        p.passed_pawn_base = p.passed_pawn_advance = 0;
        p.knight_mobility = p.bishop_mobility = p.rook_mobility = p.queen_mobility = 0;
        p.pawn_shield_bonus = p.pawn_shield_missing_penalty = p.central_king_penalty = 0;
    } else if (category == "king_safety") {
        p.pawn_value = p.knight_value = p.bishop_value = p.rook_value = p.queen_value = 0;
        p.pawn_table.fill(0); p.knight_table.fill(0); p.bishop_table.fill(0);
        p.rook_table.fill(0); p.queen_table.fill(0); p.king_table.fill(0);
        p.doubled_pawn_penalty = p.isolated_pawn_penalty = 0;
        p.passed_pawn_base = p.passed_pawn_advance = 0;
        p.knight_mobility = p.bishop_mobility = p.rook_mobility = p.queen_mobility = 0;
        p.bishop_pair_bonus = 0;
    }
    assert(p.is_valid());
    return p;
}

int main() {
    std::vector<Case> cases;
    try {
        cases = load_suite(PHASE10_SUITE_PATH);
    } catch (const std::exception& ex) {
        std::cerr << "Phase 10 setup failure: " << ex.what() << "\n";
        return 1;
    }
    if (cases.empty()) {
        std::cerr << "Phase 10 setup failure: empty suite\n";
        return 1;
    }

    std::unordered_map<std::string, const Case*> by_id;
    std::unordered_map<std::string, int> category_total;
    std::unordered_map<std::string, int> category_pass;
    for (const auto& c : cases) {
        assert(by_id.emplace(c.id, &c).second && "duplicate Phase 10 case id");
        category_total[c.category]++;
    }

    const EvaluationParams params = EvaluationParams::default_v1();
    assert(params.is_valid());

    for (const auto& original : cases) {
        auto& c = const_cast<Case&>(original);
        Position pos;
        std::string error;
        assert(set_from_fen(pos, c.fen, &error));
        assert(pos.is_consistent(&error));
        const EvaluationParams profile = isolated_profile(c.category);
        c.score = (c.category == "material") ? evaluate_material(pos, profile)
                                               : evaluate(pos, profile);
    }

    for (const auto& original : cases) {
        const auto& c = original;
        bool pass = false;
        if (c.rule == "exact_zero") {
            pass = c.score == 0;
        } else if (c.rule == "positive") {
            pass = c.score > 0;
        } else if (c.rule == "negative") {
            pass = c.score < 0;
        } else if (c.rule == "greater_than") {
            pass = c.score > by_id.at(c.reference)->score;
        } else if (c.rule == "less_than") {
            pass = c.score < by_id.at(c.reference)->score;
        } else if (c.rule == "negates") {
            pass = c.score == -by_id.at(c.reference)->score;
        } else {
            assert(false && "unknown Phase 10 rule");
        }

        if (pass) category_pass[c.category]++;
        else {
            std::cerr << "Phase 10 failure: " << c.id
                      << " score=" << c.score << " rule=" << c.rule
                      << " reference=" << c.reference << "\n";
        }
        assert(pass);
    }

    // Direct parameter-experiment sanity checks: changing one parameter must
    // affect the intended class of position while leaving parsing deterministic.
    Position pawn_pos;
    std::string error;
    assert(set_from_fen(pawn_pos, "4k3/8/8/8/4P3/8/8/4K3 w - - 0 1", &error));
    EvaluationParams custom = params;
    custom.pawn_value += 50;
    assert(evaluate(pawn_pos, custom) > evaluate(pawn_pos, params));
    const std::string serialized = custom.to_text();
    EvaluationParams round_trip;
    assert(EvaluationParams::from_text(serialized, round_trip, &error));
    assert(round_trip.to_text() == serialized);

    std::cout << "Phase 10: PASS\n";
    std::cout << "Positions: " << cases.size() << "\n";
    for (const auto& [category, total] : category_total) {
        std::cout << "  " << category << ": " << category_pass[category]
                  << "/" << total << "\n";
    }
    return 0;
}
