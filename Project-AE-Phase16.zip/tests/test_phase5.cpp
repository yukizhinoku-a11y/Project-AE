#include "chess/evaluation.hpp"
#include "chess/fen.hpp"
#include "chess/search.hpp"
#include "chess/zobrist.hpp"
#include <iostream>
#include <string>

using namespace ae::chess;
namespace {
int failures = 0;
void check(bool condition, const char* name) {
    if (!condition) { ++failures; std::cerr << "[FAIL] " << name << '\n'; }
    else std::cout << "[PASS] " << name << '\n';
}
Position fen(const char* text) {
    Position p;
    std::string error;
    if (!set_from_fen(p, text, &error)) {
        ++failures;
        std::cerr << "FEN error: " << error << '\n';
    }
    return p;
}
}

int main() {
    zobrist::init();

    const Position start = fen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
    check(evaluate_material(start) == 0, "material baseline remains zero at start");
    check(evaluate(start) == 0, "full evaluation is symmetric at start");

    const Position white_knight_center = fen("4k3/8/8/3N4/8/8/8/4K3 w - - 0 1");
    const Position white_knight_edge = fen("4k3/8/8/N7/8/8/8/4K3 w - - 0 1");
    check(evaluate(white_knight_center) > evaluate(white_knight_edge),
          "piece-square tables reward centralized knight");

    const Position passed = fen("4k3/8/4P3/8/8/8/8/4K3 w - - 0 1");
    const Position blocked = fen("4k3/4p3/4P3/8/8/8/8/4K3 w - - 0 1");
    check(evaluate(passed) > evaluate(blocked), "passed pawn structure is rewarded");

    const Position doubled = fen("4k3/8/8/8/4P3/4P3/8/4K3 w - - 0 1");
    const Position connected = fen("4k3/8/8/8/4P3/5P2/8/4K3 w - - 0 1");
    check(evaluate(connected) > evaluate(doubled), "doubled pawns are penalized");

    const Position bishop_pair = fen("4k3/8/8/8/8/8/2B1B3/4K3 w - - 0 1");
    const Position one_bishop = fen("4k3/8/8/8/8/8/2B5/4K3 w - - 0 1");
    check(evaluate(bishop_pair) > evaluate(one_bishop), "bishop pair receives a bonus");

    const Position mirrored = fen("4k3/8/8/8/8/8/3n4/4K3 b - - 0 1");
    const Position original = fen("4K3/3N4/8/8/8/8/8/4k3 w - - 0 1");
    check(evaluate(original) == -evaluate(mirrored), "evaluation is color symmetric");

    Searcher searcher;
    const auto mate = searcher.search(fen("7k/5Q2/6K1/8/8/8/8/8 w - - 0 1"), SearchLimits{2, 0});
    check(mate.best_move == Move(Square::F7, Square::G7), "search still finds mate in one");
    check(mate.score >= 29900, "mate score remains dominant over evaluation");

    if (failures == 0) std::cout << "All Phase 5 tests passed.\n";
    return failures == 0 ? 0 : 1;
}
