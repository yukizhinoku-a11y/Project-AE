#include "chess/fen.hpp"
#include "chess/search.hpp"
#include "chess/zobrist.hpp"
#include <iostream>

using namespace ae::chess;
namespace {
int failures = 0;
void check(bool condition, const char* name) {
    if (!condition) { ++failures; std::cerr << "[FAIL] " << name << '\n'; }
    else std::cout << "[PASS] " << name << '\n';
}
Position fen(const char* text) {
    Position p; std::string error;
    if (!set_from_fen(p, text, &error)) { ++failures; std::cerr << "FEN error: " << error << '\n'; }
    return p;
}
}

int main() {
    zobrist::init();
    const Position start = fen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");

    Searcher searcher;
    const auto result = searcher.search(start, SearchLimits{4, 0});
    check(result.depth == 4, "iterative deepening reaches requested depth");
    check(static_cast<bool>(result.best_move), "search returns a best move");
    check(!result.principal_variation.empty(), "transposition-aware search returns a PV");
    check(result.nodes > 0, "search counts nodes");

    const auto mate = searcher.search(fen("7k/5Q2/6K1/8/8/8/8/8 w - - 0 1"), SearchLimits{2, 0});
    check(mate.best_move == Move(Square::F7, Square::G7), "TT search still finds mate in one");
    check(mate.score >= 29900, "mate score remains dominant");

    const auto limited = searcher.search(start, SearchLimits{8, 5000});
    check(limited.nodes <= 5001, "node limit stops search near requested budget");

    if (failures == 0) std::cout << "All Phase 6 tests passed.\n";
    return failures == 0 ? 0 : 1;
}
