#include "chess/fen.hpp"
#include "chess/search.hpp"
#include "chess/zobrist.hpp"
#include <iostream>

int main() {
    using namespace ae::chess;
    zobrist::init();

    Position position;
    std::string error;
    constexpr auto start_fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
    if (!set_from_fen(position, start_fen, &error)) {
        std::cerr << "FEN failed: " << error << '\n';
        return 1;
    }

    Searcher searcher;
    const auto result = searcher.search(position, SearchLimits{4, 0});
    if (result.depth != 4 || !result.best_move || result.nodes == 0) {
        std::cerr << "search baseline failed\n";
        return 1;
    }
    if (result.metrics.nodes != result.nodes) {
        std::cerr << "node metrics mismatch\n";
        return 1;
    }
    if (result.metrics.tt_probes == 0 || result.metrics.generated_moves == 0 ||
        result.metrics.eval_calls == 0 || result.metrics.ordered_nodes == 0) {
        std::cerr << "expected search metrics were not collected\n";
        return 1;
    }
    if (result.elapsed_ms < 0.0 || result.nodes_per_second <= 0.0) {
        std::cerr << "timing metrics invalid\n";
        return 1;
    }

    std::cout << "Phase 7: PASS\n";
    std::cout << "Nodes: " << result.nodes << "\n";
    std::cout << "NPS: " << result.nodes_per_second << "\n";
    std::cout << "TT hits: " << result.metrics.tt_hits << "\n";
    std::cout << "Beta cutoffs: " << result.metrics.beta_cutoffs << "\n";
    return 0;
}
