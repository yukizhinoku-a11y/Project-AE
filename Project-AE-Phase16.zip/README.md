# Project-AE — Phase 15

## Advanced Search v2

Phase 15 upgrades the reference search with measured search-engineering techniques while preserving the existing move-generation, evaluation, transposition-table, self-play, tuning, and optimizer infrastructure.

### Added
- Principal Variation Search (PVS)
- aspiration windows during iterative deepening
- conservative null-move pruning
- Late Move Reductions (LMR) for late quiet moves
- search instrumentation for each technique
- regression coverage ensuring searched positions remain unchanged

### Metrics
`SearchMetrics` now reports:
- null-move cutoffs
- LMR reductions
- PVS zero-window searches
- aspiration-window failures

### Design
Phase 15 introduces techniques incrementally rather than replacing the existing search wholesale. The original alpha-beta/TT/quiescence path remains the correctness foundation.

Null-move pruning is intentionally conservative: it is disabled in check, at shallow depth, and in positions where the side to move has only pawns and a king.

### Validation
Build with CMake and run:

```text
cmake -S . -B build
cmake --build build --config Release
build/Release/ae_phase15_tests.exe
```

The full prior phase test suite remains part of the CTest configuration.

## Phase 16 — Search Optimization & Benchmarking

Phase 16 turns the Phase 15 search additions into measurable experiments instead of assuming they are improvements. It adds: 

- selectable search options for PVS, LMR, null-move pruning, and aspiration windows
- a Phase-7-style baseline mode with the Phase-15 additions disabled
- isolated feature benchmark rows (`+PVS`, `+LMR`, `+null`, `+asp`)
- an all-features `V2` configuration
- per-position timing, nodes, NPS, TT hits, and search-feature counters
- completed-depth reporting under a node budget
- a release-safe Phase 16 regression test
- a quiescence-search optimization that sorts only tactical moves when the side is not in check, avoiding work on quiet moves that will not be searched

### Benchmark

After building, run:

```text
build\Release\ae_phase16_benchmark.exe
```

Optional arguments are:

```text
ae_phase16_benchmark.exe <depth> <repeats> <node_limit>
```

The default is a small node budget so the benchmark remains practical during development. For serious measurements, use a fixed executable/build configuration, repeat the benchmark, and compare the same positions and limits. Do not treat a result from an interrupted iteration as a completed-depth strength comparison.

The historical Phase 7 Windows baseline was approximately **73,746 aggregate NPS** on the development machine. Phase 16 intentionally does not claim a new performance baseline until the user's current Windows build is measured under the same conditions.

### Research rule

A search feature is kept because measured search efficiency, node reduction, or playing strength justifies it—not because the feature sounds stronger. Phase 16 therefore separates feature effects and records instrumentation needed for later decisions.
